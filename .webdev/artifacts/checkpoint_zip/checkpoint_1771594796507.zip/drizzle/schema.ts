import { mysqlTable, mysqlSchema, AnyMySqlColumn, int, varchar, mysqlEnum, json, text, timestamp, decimal, index, foreignKey } from "drizzle-orm/mysql-core"
import { sql } from "drizzle-orm"

export const adminLogs = mysqlTable("admin_logs", {
	id: int().autoincrement().notNull(),
	adminId: int().notNull(),
	adminName: varchar({ length: 200 }),
	action: mysqlEnum(['create','update','delete','activate','deactivate','export','view']).notNull(),
	targetType: mysqlEnum(['user','project','ip','organization','analysis','system']).notNull(),
	targetId: int(),
	targetName: varchar({ length: 500 }),
	details: json(),
	ipAddress: varchar({ length: 50 }),
	userAgent: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const ambassadors = mysqlTable("ambassadors", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	country: varchar({ length: 100 }).notNull(),
	city: varchar({ length: 100 }),
	region: varchar({ length: 100 }),
	title: varchar({ length: 200 }),
	organization: varchar({ length: 200 }),
	bio: text(),
	expertise: json(),
	languages: json(),
	status: mysqlEnum(['pending','active','inactive','suspended']).default('pending'),
	appointedAt: timestamp({ mode: 'string' }),
	achievements: json(),
	connections: int().default(0),
	dealsIntroduced: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const analytics = mysqlTable("analytics", {
	id: int().autoincrement().notNull(),
	date: timestamp({ mode: 'string' }).notNull(),
	metric: varchar({ length: 100 }).notNull(),
	value: decimal({ precision: 15, scale: 2 }).notNull(),
	dimension: varchar({ length: 100 }),
	dimensionValue: varchar({ length: 200 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const analyticsEvents = mysqlTable("analytics_events", {
	id: int().autoincrement().notNull(),
	eventType: mysqlEnum(['page_view','idea_submitted','idea_analyzed','challenge_created','challenge_submitted','hackathon_registered','match_suggested','match_accepted','asset_listed','asset_viewed','asset_sold','contract_created','contract_signed','escrow_funded','user_registered','user_login']).notNull(),
	userId: int(),
	sessionId: varchar({ length: 100 }),
	ipAddress: varchar({ length: 45 }),
	userAgent: text(),
	entityType: varchar({ length: 50 }),
	entityId: int(),
	metadata: json(),
	country: varchar({ length: 100 }),
	city: varchar({ length: 100 }),
	eventTimestamp: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const apiKeys = mysqlTable("api_keys", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 200 }).notNull(),
	keyHash: varchar({ length: 256 }).notNull(),
	keyPrefix: varchar({ length: 20 }).notNull(),
	permissions: json(),
	rateLimit: int().default(1000),
	status: mysqlEnum(['active','revoked','expired']).default('active'),
	lastUsedAt: timestamp({ mode: 'string' }),
	expiresAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const apiUsage = mysqlTable("api_usage", {
	id: int().autoincrement().notNull(),
	apiKeyId: int().notNull(),
	endpoint: varchar({ length: 500 }).notNull(),
	method: varchar({ length: 10 }).notNull(),
	statusCode: int(),
	responseTime: int(),
	ipAddress: varchar({ length: 50 }),
	userAgent: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const assetInquiries = mysqlTable("asset_inquiries", {
	id: int().autoincrement().notNull(),
	assetId: int().notNull(),
	buyerId: int().notNull(),
	message: text().notNull(),
	offerPrice: decimal({ precision: 15, scale: 2 }),
	proposedTerms: text(),
	status: mysqlEnum(['pending','responded','negotiating','accepted','rejected','expired']).default('pending'),
	sellerResponse: text(),
	respondedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const assetTransactions = mysqlTable("asset_transactions", {
	id: int().autoincrement().notNull(),
	assetId: int().notNull(),
	sellerId: int().notNull(),
	buyerId: int().notNull(),
	finalPrice: decimal({ precision: 15, scale: 2 }).notNull(),
	currency: varchar({ length: 10 }).default('SAR'),
	contractId: int(),
	escrowId: int(),
	status: mysqlEnum(['pending','escrow_funded','in_progress','completed','disputed','cancelled','refunded']).default('pending'),
	initiatedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	completedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const auditLogs = mysqlTable("audit_logs", {
	id: int().autoincrement().notNull(),
	userId: int(),
	action: varchar({ length: 100 }).notNull(),
	resource: varchar({ length: 100 }).notNull(),
	resourceId: varchar({ length: 100 }),
	details: json(),
	ipAddress: varchar({ length: 45 }),
	userAgent: text(),
	status: mysqlEnum(['success','failure']).default('success'),
	errorMessage: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const challengeSubmissions = mysqlTable("challenge_submissions", {
	id: int().autoincrement().notNull(),
	challengeId: int().notNull(),
	userId: int().notNull(),
	ideaId: int(),
	title: varchar({ length: 500 }).notNull(),
	description: text().notNull(),
	solution: text().notNull(),
	expectedImpact: text(),
	teamName: varchar({ length: 200 }),
	teamMembers: json(),
	teamSize: int().default(1),
	documents: json(),
	images: json(),
	video: text(),
	prototype: text(),
	evaluationScore: decimal({ precision: 5, scale: 2 }),
	evaluationNotes: text(),
	rank: int(),
	score: decimal({ precision: 5, scale: 2 }),
	reviewerComments: text(),
	publicVotes: int().default(0),
	judgeVotes: int().default(0),
	status: mysqlEnum(['draft','submitted','under_review','shortlisted','winner','rejected','finalist']).default('draft'),
	submittedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const challenges = mysqlTable("challenges", {
	id: int().autoincrement().notNull(),
	organizerId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	type: mysqlEnum(['challenge','hackathon','competition','open_problem','conference']).notNull(),
	category: varchar({ length: 100 }),
	prize: decimal({ precision: 15, scale: 2 }),
	currency: varchar({ length: 10 }).default('SAR'),
	status: mysqlEnum(['draft','open','closed','judging','completed','cancelled','active','upcoming']).default('draft'),
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	requirements: json(),
	judges: json(),
	sponsors: json(),
	participants: int().default(0),
	submissions: int().default(0),
	winnerId: int(),
	budget: decimal({ precision: 15, scale: 2 }),
	criteria: json(),
	reward: varchar({ length: 500 }),
	deadline: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const challengesNew = mysqlTable("challenges_new", {
	id: int().autoincrement().notNull(),
	ownerId: int().notNull(),
	ownerType: mysqlEnum(['ministry','company','government','ngo']).notNull(),
	ownerName: varchar({ length: 300 }).notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	problemStatement: text().notNull(),
	desiredOutcome: text(),
	category: varchar({ length: 100 }),
	subCategory: varchar({ length: 100 }),
	industry: varchar({ length: 100 }),
	keywords: json(),
	eligibilityCriteria: json(),
	technicalRequirements: json(),
	constraints: json(),
	totalPrizePool: decimal({ precision: 15, scale: 2 }),
	currency: varchar({ length: 10 }).default('SAR'),
	prizeDistribution: json(),
	fundingAvailable: decimal({ precision: 15, scale: 2 }),
	startDate: timestamp({ mode: 'string' }).notNull(),
	endDate: timestamp({ mode: 'string' }).notNull(),
	submissionDeadline: timestamp({ mode: 'string' }).notNull(),
	evaluationDeadline: timestamp({ mode: 'string' }),
	announcementDate: timestamp({ mode: 'string' }),
	status: mysqlEnum(['draft','open','submission_closed','evaluating','completed','cancelled']).default('draft'),
	submissionsCount: int().default(0),
	participantsCount: int().default(0),
	views: int().default(0),
	documents: json(),
	images: json(),
	publishedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const classificationHistory = mysqlTable("classification_history", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	analysisId: int().notNull(),
	classification: mysqlEnum(['innovation','commercial','weak']).notNull(),
	overallScore: decimal({ precision: 5, scale: 2 }).notNull(),
	userFeedback: mysqlEnum(['accepted','appealed','revised','abandoned']),
	feedbackNotes: text(),
	appealReason: text(),
	appealStatus: mysqlEnum(['none','pending','approved','rejected']).default('none'),
	appealReviewedBy: int(),
	appealReviewedAt: timestamp({ mode: 'string' }),
	appealNotes: text(),
	revisionNumber: int().default(1),
	previousClassification: mysqlEnum(['innovation','commercial','weak']),
	classifiedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const contracts = mysqlTable("contracts", {
	id: int().autoincrement().notNull(),
	contractType: mysqlEnum("contract_type", ['idea_contract','challenge_contract','event_contract','asset_license','asset_purchase','acquisition','partnership','service','other']).default('other'),
	sourceType: mysqlEnum("source_type", ['naqla1_idea','naqla2_challenge','naqla2_event','naqla3_asset','manual']).default('manual'),
	sourceId: int("source_id"),
	projectId: int().notNull(),
	type: mysqlEnum(['license','acquisition','partnership','investment','service','nda']).notNull(),
	title: varchar({ length: 500 }).notNull(),
	description: text(),
	partyA: int().notNull(),
	partyB: int().notNull(),
	totalValue: decimal({ precision: 15, scale: 2 }).notNull(),
	currency: varchar({ length: 10 }).default('SAR'),
	status: mysqlEnum(['draft','pending_signatures','active','completed','disputed','terminated','expired']).default('draft'),
	terms: text(),
	milestones: json(),
	documents: json(),
	partyAsignature: text(),
	partyAsignedAt: timestamp({ mode: 'string' }),
	partyBsignature: text(),
	partyBsignedAt: timestamp({ mode: 'string' }),
	// حقول التوقيع الإلكتروني
	sellerSignatureUrl: varchar('seller_signature_url', { length: 500 }),
	buyerSignatureUrl: varchar('buyer_signature_url', { length: 500 }),
	sellerSignedAt: timestamp('seller_signed_at', { mode: 'string' }),
	buyerSignedAt: timestamp('buyer_signed_at', { mode: 'string' }),
	signedPdfUrl: varchar('signed_pdf_url', { length: 500 }),
	blockchainHash: varchar({ length: 256 }),
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const courses = mysqlTable("courses", {
	id: int().autoincrement().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text(),
	descriptionEn: text(),
	category: mysqlEnum(['innovation','entrepreneurship','ip','investment','technology','leadership']).notNull(),
	level: mysqlEnum(['beginner','intermediate','advanced','expert']).default('beginner'),
	duration: int(),
	modules: json(),
	instructor: varchar({ length: 200 }),
	instructorBio: text(),
	partner: varchar({ length: 200 }),
	thumbnail: text(),
	video: text(),
	price: decimal({ precision: 10, scale: 2 }).default('0'),
	isFree: int().default(1),
	certificateEnabled: int().default(1),
	enrollmentCount: int().default(0),
	rating: decimal({ precision: 3, scale: 2 }),
	isPublished: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const dataVisibilityRules = mysqlTable("data_visibility_rules", {
	id: int().autoincrement().notNull(),
	roleId: int().notNull(),
	resourceType: varchar({ length: 100 }).notNull(),
	visibilityScope: mysqlEnum(['all','own','department','team','custom']).notNull(),
	customFilter: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const eliteMemberships = mysqlTable("elite_memberships", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	tier: mysqlEnum(['gold','platinum','diamond']).notNull(),
	status: mysqlEnum(['active','expired','cancelled','pending']).default('pending'),
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	price: decimal({ precision: 10, scale: 2 }),
	paymentStatus: mysqlEnum(['pending','paid','failed','refunded']).default('pending'),
	benefits: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const enrollments = mysqlTable("enrollments", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	courseId: int().notNull(),
	progress: int().default(0),
	completedModules: json(),
	status: mysqlEnum(['enrolled','in_progress','completed','dropped']).default('enrolled'),
	startedAt: timestamp({ mode: 'string' }),
	completedAt: timestamp({ mode: 'string' }),
	certificateId: varchar({ length: 100 }),
	certificateIssuedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const escrowAccounts = mysqlTable("escrow_accounts", {
	id: int().autoincrement().notNull(),
	contractId: int().notNull(),
	totalAmount: decimal({ precision: 15, scale: 2 }).notNull(),
	releasedAmount: decimal({ precision: 15, scale: 2 }).default('0'),
	pendingAmount: decimal({ precision: 15, scale: 2 }),
	currency: varchar({ length: 10 }).default('SAR'),
	status: mysqlEnum(['pending_deposit','funded','partially_released','fully_released','refunded','disputed']).default('pending_deposit'),
	depositedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const escrowTransactions = mysqlTable("escrow_transactions", {
	id: int().autoincrement().notNull(),
	escrowId: int().notNull(),
	type: mysqlEnum(['deposit','release','refund','fee']).notNull(),
	amount: decimal({ precision: 15, scale: 2 }).notNull(),
	milestoneId: varchar({ length: 100 }),
	description: text(),
	status: mysqlEnum(['pending','completed','failed','reversed']).default('pending'),
	transactionHash: varchar({ length: 256 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const evaluationCriteria = mysqlTable("evaluation_criteria", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 100 }).notNull(),
	nameEn: varchar({ length: 100 }),
	description: text(),
	descriptionEn: text(),
	weight: decimal({ precision: 5, scale: 2 }).notNull(),
	guidelines: json(),
	examples: json(),
	isActive: int().default(1),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("evaluation_criteria_name_unique").on(table.name),
]);

export const evaluations = mysqlTable("evaluations", {
	id: int().autoincrement().notNull(),
	projectId: int().notNull(),
	evaluatorId: int(),
	overallScore: decimal({ precision: 5, scale: 2 }).notNull(),
	classification: mysqlEnum(['innovation','commercial','guidance']).notNull(),
	innovationScore: decimal({ precision: 5, scale: 2 }),
	marketPotentialScore: decimal({ precision: 5, scale: 2 }),
	technicalFeasibilityScore: decimal({ precision: 5, scale: 2 }),
	teamCapabilityScore: decimal({ precision: 5, scale: 2 }),
	ipStrengthScore: decimal({ precision: 5, scale: 2 }),
	scalabilityScore: decimal({ precision: 5, scale: 2 }),
	aiAnalysis: text(),
	strengths: json(),
	weaknesses: json(),
	recommendations: json(),
	nextSteps: json(),
	marketAnalysis: text(),
	competitorAnalysis: text(),
	riskAssessment: text(),
	status: mysqlEnum(['pending','in_progress','completed','appealed']).default('pending'),
	appealNotes: text(),
	appealStatus: mysqlEnum(['none','pending','approved','rejected']).default('none'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const eventRegistrations = mysqlTable("event_registrations", {
	id: int().autoincrement().notNull(),
	eventId: int("event_id").notNull().references(() => events.id, { onDelete: "cascade" } ),
	userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" } ),
	registrationType: mysqlEnum("registration_type", ['attendee','speaker','sponsor','volunteer','exhibitor']).notNull(),
	status: mysqlEnum(['pending','confirmed','cancelled','attended','no_show']).default('pending'),
	paymentStatus: mysqlEnum("payment_status", ['not_required','pending','paid','refunded']).default('not_required'),
	paymentAmount: decimal("payment_amount", { precision: 10, scale: 2 }),
	specialRequirements: text("special_requirements"),
	dietaryPreferences: varchar("dietary_preferences", { length: 255 }),
	tShirtSize: varchar("t_shirt_size", { length: 10 }),
	attendanceCertificateIssued: int("attendance_certificate_issued").default(0),
	feedback: text(),
	rating: int(),
	createdAt: timestamp("created_at", { mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("unique_event_user").on(table.eventId, table.userId),
]);

export const events = mysqlTable("events", {
	id: int().autoincrement().notNull(),
	organizerId: int("organizer_id").notNull().references(() => users.id, { onDelete: "cascade" } ),
	title: varchar({ length: 500 }).notNull(),
	description: text().notNull(),
	eventType: mysqlEnum("event_type", ['conference','workshop','hackathon','seminar','webinar','networking','exhibition','competition','training']).notNull(),
	deliveryMode: mysqlEnum("delivery_mode", ['online','in_person','hybrid']).notNull(),
	category: varchar({ length: 100 }),
	startDate: timestamp("start_date", { mode: 'string' }).notNull(),
	endDate: timestamp("end_date", { mode: 'string' }).notNull(),
	location: text(),
	onlinePlatform: varchar("online_platform", { length: 255 }),
	meetingLink: text("meeting_link"),
	capacity: int(),
	registrationDeadline: timestamp("registration_deadline", { mode: 'string' }),
	registrationFee: decimal("registration_fee", { precision: 10, scale: 2 }).default('0'),
	targetAudience: text("target_audience"),
	objectives: text(),
	agenda: json(),
	speakers: json(),
	sponsorsNeeded: int("sponsors_needed").default(0),
	sponsorPackages: json("sponsor_packages"),
	confirmedSponsors: json("confirmed_sponsors"),
	innovatorsNeeded: int("innovators_needed").default(0),
	requiredSkills: json("required_skills"),
	matchedInnovators: json("matched_innovators"),
	status: mysqlEnum(['draft','pending_approval','approved','rejected','published','ongoing','completed','cancelled']).default('draft'),
	approvalDate: timestamp("approval_date", { mode: 'string' }),
	approvedBy: int("approved_by"),
	rejectionReason: text("rejection_reason"),
	contractId: int("contract_id"),
	images: json(),
	documents: json(),
	website: text(),
	socialMedia: json("social_media"),
	registrationCount: int("registration_count").default(0),
	attendanceCount: int("attendance_count").default(0),
	registrations: json(),
	budget: decimal({ precision: 12, scale: 2 }),
	isVirtual: int("is_virtual").default(0),
	feedbackScore: decimal("feedback_score", { precision: 3, scale: 2 }),
	createdAt: timestamp("created_at", { mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const gateDecisions = mysqlTable("gate_decisions", {
	id: int().autoincrement().notNull(),
	innovationId: int().notNull(),
	stage: varchar({ length: 100 }).notNull(),
	decisionType: mysqlEnum(['continue','park','kill']).notNull(),
	rationale: text().notNull(),
	decisionDate: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	deciderId: int().notNull(),
	validationResults: json(),
	remainingRaTs: json(),
	resourcesConsumed: decimal({ precision: 15, scale: 2 }),
	keyLearnings: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const hackathonRegistrations = mysqlTable("hackathon_registrations", {
	id: int().autoincrement().notNull(),
	hackathonId: int().notNull(),
	userId: int().notNull(),
	teamName: varchar({ length: 200 }),
	teamMembers: json(),
	teamSize: int().default(1),
	motivation: text(),
	skills: json(),
	experience: text(),
	status: mysqlEnum(['pending','approved','rejected','waitlisted','cancelled']).default('pending'),
	checkedIn: int().default(0),
	checkInTime: timestamp({ mode: 'string' }),
	registeredAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const hackathons = mysqlTable("hackathons", {
	id: int().autoincrement().notNull(),
	organizerId: int().notNull(),
	organizerName: varchar({ length: 300 }).notNull(),
	name: varchar({ length: 500 }).notNull(),
	nameEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	theme: varchar({ length: 200 }),
	type: mysqlEnum(['hackathon','workshop','conference','competition','bootcamp']).notNull(),
	format: mysqlEnum(['online','onsite','hybrid']).notNull(),
	country: varchar({ length: 100 }),
	city: varchar({ length: 100 }),
	venue: varchar({ length: 300 }),
	address: text(),
	startDate: timestamp({ mode: 'string' }).notNull(),
	endDate: timestamp({ mode: 'string' }).notNull(),
	registrationDeadline: timestamp({ mode: 'string' }).notNull(),
	maxParticipants: int(),
	currentParticipants: int().default(0),
	totalPrizePool: decimal({ precision: 15, scale: 2 }),
	currency: varchar({ length: 10 }).default('SAR'),
	prizes: json(),
	eligibilityCriteria: json(),
	requiredSkills: json(),
	sponsors: json(),
	status: mysqlEnum(['draft','registration_open','registration_closed','ongoing','completed','cancelled']).default('draft'),
	agenda: json(),
	documents: json(),
	images: json(),
	views: int().default(0),
	publishedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const ideaAnalysis = mysqlTable("idea_analysis", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	overallScore: decimal({ precision: 5, scale: 2 }).notNull(),
	classification: mysqlEnum(['innovation','commercial','weak']).notNull(),
	technicalNoveltyScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	socialImpactScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	technicalFeasibilityScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	commercialValueScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	scalabilityScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	sustainabilityScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	technicalRiskScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	timeToMarketScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	competitiveAdvantageScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	organizationalReadinessScore: decimal({ precision: 5, scale: 2 }).default('0').notNull(),
	trlLevel: int(),
	trlDescription: text(),
	currentStageGate: mysqlEnum(['ideation','scoping','business_case','development','testing','launch']),
	stageGateRecommendation: text(),
	aiAnalysis: text(),
	strengths: json(),
	weaknesses: json(),
	opportunities: json(),
	threats: json(),
	recommendations: json(),
	nextSteps: json(),
	similarInnovations: json(),
	extractedKeywords: json(),
	sentimentScore: decimal({ precision: 5, scale: 2 }),
	complexityLevel: mysqlEnum(['low','medium','high','very_high']),
	marketSize: text(),
	competitionLevel: mysqlEnum(['low','medium','high','very_high']),
	marketTrends: json(),
	status: mysqlEnum(['pending','completed','failed']).default('pending'),
	processingTime: int(),
	analyzedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("ideaId").on(table.ideaId),
]);

export const ideaOrganizations = mysqlTable("idea_organizations", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	organizationId: int().notNull(),
	role: varchar({ length: 100 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const ideaOutcomes = mysqlTable("idea_outcomes", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	description: text().notNull(),
	category: varchar({ length: 100 }),
	budget: decimal({ precision: 15, scale: 2 }),
	teamSize: int(),
	timelineMonths: int(),
	marketDemand: decimal({ precision: 5, scale: 2 }),
	technicalFeasibility: decimal({ precision: 5, scale: 2 }),
	competitiveAdvantage: decimal({ precision: 5, scale: 2 }),
	userEngagement: decimal({ precision: 5, scale: 2 }),
	tagsCount: int(),
	hypothesisValidationRate: decimal({ precision: 5, scale: 2 }),
	ratCompletionRate: decimal({ precision: 5, scale: 2 }),
	outcome: mysqlEnum(['success','failure','pending']).default('pending').notNull(),
	outcomeDate: timestamp({ mode: 'string' }),
	outcomeNotes: text(),
	classifiedBy: int(),
	classifiedAt: timestamp({ mode: 'string' }),
	predictedSuccessRate: decimal({ precision: 5, scale: 2 }),
	predictionModel: varchar({ length: 100 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const ideas = mysqlTable("ideas", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	problem: text(),
	solution: text(),
	targetMarket: text(),
	uniqueValue: text(),
	category: varchar({ length: 100 }),
	subCategory: varchar({ length: 100 }),
	keywords: json(),
	documents: json(),
	images: json(),
	status: mysqlEnum(['draft','submitted','analyzing','analyzed','revision_needed','approved','commercial','pending','accepted','rejected']).default('draft'),
	analysisId: int(),
	submittedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	challengeId: int(),
	naqla2ProjectId: int("naqla2_project_id"),
	naqla3AssetId: int("naqla3_asset_id"),
	userChoice: mysqlEnum('user_choice', ['naqla2', 'naqla3']),
	overallScore: int(),
	classificationPath: varchar({ length: 500 }),
	clusterId: int("cluster_id"),
});

export const ideaClusters = mysqlTable("idea_clusters", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 300 }).notNull(),
	nameEn: varchar({ length: 300 }),
	description: text(),
	descriptionEn: text(),
	strength: int().default(0),
	memberCount: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	createdBy: int(),
});

export const ideaClusterMembers = mysqlTable("idea_cluster_members", {
	id: int().autoincrement().notNull(),
	clusterId: int("cluster_id").notNull(),
	ideaId: int("idea_id").notNull(),
	similarity: int().default(0),
	addedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	addedBy: int(),
});

export const innovationHubs = mysqlTable("innovation_hubs", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 200 }).notNull(),
	nameEn: varchar({ length: 200 }),
	country: varchar({ length: 100 }).notNull(),
	city: varchar({ length: 100 }).notNull(),
	address: text(),
	type: mysqlEnum(['hub','accelerator','incubator','university','research_center','corporate']).notNull(),
	description: text(),
	website: text(),
	contactEmail: varchar({ length: 320 }),
	contactPhone: varchar({ length: 50 }),
	partnerSince: timestamp({ mode: 'string' }),
	status: mysqlEnum(['active','inactive','pending']).default('pending'),
	logo: text(),
	coordinates: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const innovationHypotheses = mysqlTable("innovation_hypotheses", {
	id: int().autoincrement().notNull(),
	innovationId: int().notNull(),
	userId: int().notNull(),
	statement: text().notNull(),
	statementEn: text(),
	assumption: text(),
	metric: varchar({ length: 255 }),
	successCriterion: text(),
	testMethod: text(),
	riskLevel: mysqlEnum(['high','medium','low']).default('medium'),
	uncertaintyLevel: mysqlEnum(['high','medium','low']).default('medium'),
	impactIfWrong: mysqlEnum(['critical','major','minor']).default('major'),
	ratScore: decimal({ precision: 5, scale: 2 }),
	status: mysqlEnum(['pending','testing','validated','invalidated']).default('pending'),
	testResult: text(),
	evidence: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const innovatorApplications = mysqlTable("innovator_applications", {
	id: int().autoincrement().notNull(),
	eventId: int("event_id").notNull().references(() => events.id, { onDelete: "cascade" } ),
	innovatorId: int("innovator_id").notNull().references(() => users.id, { onDelete: "cascade" } ),
	applicationType: mysqlEnum("application_type", ['participant','presenter','competitor']).notNull(),
	projectTitle: varchar("project_title", { length: 500 }),
	projectDescription: text("project_description"),
	skills: json(),
	portfolioLink: text("portfolio_link"),
	motivation: text(),
	status: mysqlEnum(['pending','under_review','accepted','rejected','waitlist']).default('pending'),
	reviewedBy: int("reviewed_by"),
	reviewDate: timestamp("review_date", { mode: 'string' }),
	reviewScore: decimal("review_score", { precision: 5, scale: 2 }),
	reviewNotes: text("review_notes"),
	createdAt: timestamp("created_at", { mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const ipRegistrations = mysqlTable("ip_registrations", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	type: mysqlEnum(['patent','trademark','copyright','trade_secret','industrial_design']).notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	category: varchar({ length: 100 }),
	subCategory: varchar({ length: 100 }),
	keywords: json(),
	inventors: json(),
	applicantType: mysqlEnum(['individual','company','university','government']),
	priorityDate: timestamp({ mode: 'string' }),
	filingDate: timestamp({ mode: 'string' }),
	status: mysqlEnum(['draft','submitted','under_review','approved','rejected','registered','expired']).default('draft'),
	saipApplicationNumber: varchar({ length: 100 }),
	wipoApplicationNumber: varchar({ length: 100 }),
	blockchainHash: varchar({ length: 256 }),
	blockchainTimestamp: timestamp({ mode: 'string' }),
	documents: json(),
	fees: decimal({ precision: 12, scale: 2 }),
	feesPaid: int().default(0),
	expiryDate: timestamp({ mode: 'string' }),
	notes: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const knowledgeBaseItems = mysqlTable("knowledge_base_items", {
	id: int().autoincrement().notNull(),
	sourceType: mysqlEnum(['learning','decision','experiment','retrospective']).notNull(),
	sourceId: int(),
	content: text().notNull(),
	contentEn: text(),
	category: varchar({ length: 100 }),
	tags: json(),
	rating: decimal({ precision: 3, scale: 2 }),
	viewCount: int().default(0),
	helpfulCount: int().default(0),
	notHelpfulCount: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const knowledgeRatings = mysqlTable("knowledge_ratings", {
	id: int().autoincrement().notNull(),
	itemId: int().notNull(),
	userId: int().notNull(),
	isHelpful: int().notNull(),
	comment: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const learningLogs = mysqlTable("learning_logs", {
	id: int().autoincrement().notNull(),
	innovationId: int().notNull(),
	userId: int().notNull(),
	stage: varchar({ length: 100 }),
	lessonLearned: text().notNull(),
	lessonLearnedEn: text(),
	impact: mysqlEnum(['high','medium','low']).default('medium'),
	recommendation: text(),
	tags: json(),
	category: varchar({ length: 100 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const marketplaceAssets = mysqlTable("marketplace_assets", {
	id: int().autoincrement().notNull(),
	ownerId: int().notNull(),
	assetType: mysqlEnum(['license','product','acquisition']).notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	price: decimal({ precision: 15, scale: 2 }).notNull(),
	currency: varchar({ length: 10 }).default('SAR'),
	pricingModel: mysqlEnum(['fixed','negotiable','royalty','subscription','revenue_share']).default('fixed'),
	licenseType: mysqlEnum(['exclusive','non_exclusive','sole','sublicensable']),
	licenseDuration: varchar({ length: 100 }),
	royaltyRate: decimal({ precision: 5, scale: 2 }),
	productCategory: varchar({ length: 100 }),
	productCondition: mysqlEnum(['new','used','refurbished']),
	inventory: int(),
	companyName: varchar({ length: 300 }),
	companyValuation: decimal({ precision: 15, scale: 2 }),
	revenue: decimal({ precision: 15, scale: 2 }),
	employees: int(),
	foundedYear: int(),
	category: varchar({ length: 100 }),
	industry: varchar({ length: 100 }),
	keywords: json(),
	ipRegistrationId: int(),
	patentNumber: varchar({ length: 100 }),
	trademarkNumber: varchar({ length: 100 }),
	dueDiligenceReport: text(),
	financialStatements: json(),
	legalDocuments: json(),
	images: json(),
	videos: json(),
	documents: json(),
	status: mysqlEnum(['draft','pending_review','active','sold','delisted','expired']).default('draft'),
	views: int().default(0),
	inquiries: int().default(0),
	listedAt: timestamp({ mode: 'string' }),
	soldAt: timestamp({ mode: 'string' }),
	expiresAt: timestamp({ mode: 'string' }),
	rating: decimal({ precision: 3, scale: 2 }),
	priceType: varchar({ length: 50 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const matchingRequests = mysqlTable("matching_requests", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	userType: mysqlEnum(['innovator','investor','company','government']).notNull(),
	title: varchar({ length: 500 }).notNull(),
	description: text().notNull(),
	lookingFor: mysqlEnum(['investor','co_founder','technical_partner','business_partner','mentor','innovation','startup','technology']).notNull(),
	industry: json(),
	stage: json(),
	location: json(),
	fundingRange: json(),
	keywords: json(),
	requiredSkills: json(),
	preferredAttributes: json(),
	status: mysqlEnum(['active','matched','paused','closed']).default('active'),
	matchesCount: int().default(0),
	expiresAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const matchingResults = mysqlTable("matching_results", {
	id: int().autoincrement().notNull(),
	requestId: int().notNull(),
	matchedUserId: int(),
	matchedProjectId: int(),
	matchedIdeaId: int(),
	matchScore: decimal({ precision: 5, scale: 2 }).notNull(),
	matchingFactors: json(),
	aiAnalysis: text(),
	status: mysqlEnum(['suggested','viewed','contacted','accepted','rejected','expired']).default('suggested'),
	viewedAt: timestamp({ mode: 'string' }),
	contactedAt: timestamp({ mode: 'string' }),
	respondedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const networkingConnections = mysqlTable("networking_connections", {
	id: int().autoincrement().notNull(),
	userAid: int().notNull(),
	userBid: int().notNull(),
	connectionType: mysqlEnum(['match','challenge','hackathon','direct','referral']).notNull(),
	contextId: int(),
	status: mysqlEnum(['pending','accepted','rejected','blocked']).default('pending'),
	message: text(),
	notes: text(),
	acceptedAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	type: mysqlEnum(['info','success','warning','error','action']).default('info'),
	title: varchar({ length: 200 }).notNull(),
	message: text().notNull(),
	link: text(),
	isRead: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const organizations = mysqlTable("organizations", {
	id: int().autoincrement().notNull(),
	nameAr: varchar({ length: 500 }).notNull(),
	nameEn: varchar({ length: 500 }),
	type: mysqlEnum(['government','academic','private','supporting']).notNull(),
	scope: mysqlEnum(['local','global']).default('local').notNull(),
	description: text(),
	website: text(),
	logo: text(),
	contactEmail: varchar({ length: 320 }),
	contactPhone: varchar({ length: 20 }),
	address: text(),
	country: varchar({ length: 100 }).default('Saudi Arabia'),
	city: varchar({ length: 100 }),
	isActive: int().default(1),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const permissions = mysqlTable("permissions", {
	id: int().autoincrement().notNull(),
	resource: varchar({ length: 100 }).notNull(),
	action: varchar({ length: 50 }).notNull(),
	displayName: varchar({ length: 200 }).notNull(),
	description: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const pipelineChallenges = mysqlTable("pipeline_challenges", {
	id: int().autoincrement().notNull(),
	initiativeId: int().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text(),
	descriptionEn: text(),
	problemStatement: text(),
	desiredOutcome: text(),
	constraints: json(),
	status: mysqlEnum(['open','ideation','evaluation','closed']).default('open'),
	priority: mysqlEnum(['low','medium','high','critical']).default('medium'),
	deadline: timestamp({ mode: 'string' }),
	ideasCount: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineClusters = mysqlTable("pipeline_clusters", {
	id: int().autoincrement().notNull(),
	initiativeId: int().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 200 }).notNull(),
	nameEn: varchar({ length: 200 }),
	description: text(),
	theme: varchar({ length: 200 }),
	color: varchar({ length: 20 }),
	status: mysqlEnum(['active','parked','killed','merged']).default('active'),
	ideasCount: int().default(0),
	avgScore: decimal({ precision: 5, scale: 2 }),
	priority: mysqlEnum(['low','medium','high']).default('medium'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineExperiments = mysqlTable("pipeline_experiments", {
	id: int().autoincrement().notNull(),
	hypothesisId: int().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 300 }).notNull(),
	nameEn: varchar({ length: 300 }),
	description: text(),
	experimentType: mysqlEnum(['survey','interview','prototype','mvp','ab_test','landing_page','concierge','wizard_of_oz']).default('prototype'),
	status: mysqlEnum(['planned','in_progress','completed','cancelled']).default('planned'),
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	budget: decimal({ precision: 10, scale: 2 }),
	sampleSize: int(),
	methodology: text(),
	metrics: json(),
	results: text(),
	learnings: text(),
	outcome: mysqlEnum(['pending','supports','rejects','inconclusive']).default('pending'),
	nextSteps: text(),
	attachments: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineGamification = mysqlTable("pipeline_gamification", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	totalPoints: int().default(0),
	level: int().default(1),
	ideasSubmitted: int().default(0),
	ideasApproved: int().default(0),
	experimentsRun: int().default(0),
	hypothesesValidated: int().default(0),
	votesGiven: int().default(0),
	commentsGiven: int().default(0),
	badges: json(),
	achievements: json(),
	streak: int().default(0),
	lastActivityAt: timestamp({ mode: 'string' }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineHypotheses = mysqlTable("pipeline_hypotheses", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	userId: int().notNull(),
	statement: text().notNull(),
	statementEn: text(),
	type: mysqlEnum(['desirability','feasibility','viability']).default('desirability'),
	assumption: text(),
	riskLevel: mysqlEnum(['low','medium','high','critical']).default('medium'),
	status: mysqlEnum(['untested','testing','validated','invalidated','refined']).default('untested'),
	validationMethod: text(),
	successCriteria: text(),
	evidence: text(),
	confidence: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineIdeas = mysqlTable("pipeline_ideas", {
	id: int().autoincrement().notNull(),
	challengeId: int().notNull(),
	userId: int().notNull(),
	clusterId: int(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text(),
	descriptionEn: text(),
	solution: text(),
	expectedImpact: text(),
	estimatedCost: decimal({ precision: 15, scale: 2 }),
	estimatedRoi: decimal({ precision: 5, scale: 2 }),
	implementationTime: varchar({ length: 100 }),
	status: mysqlEnum(['submitted','under_review','approved','parked','killed','in_experiment']).default('submitted'),
	votes: int().default(0),
	aiScore: decimal({ precision: 5, scale: 2 }),
	aiAnalysis: text(),
	riskLevel: mysqlEnum(['low','medium','high']).default('medium'),
	innovationLevel: mysqlEnum(['incremental','adjacent','transformational']).default('incremental'),
	tags: json(),
	attachments: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	projectId: int(),
});

export const pipelineInitiatives = mysqlTable("pipeline_initiatives", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text(),
	descriptionEn: text(),
	businessStrategy: text(),
	innovationStrategy: text(),
	priority: mysqlEnum(['low','medium','high','critical']).default('medium'),
	status: mysqlEnum(['draft','active','paused','completed','cancelled']).default('draft'),
	budget: decimal({ precision: 15, scale: 2 }),
	budgetSpent: decimal({ precision: 15, scale: 2 }).default('0'),
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	owner: int(),
	team: json(),
	kpis: json(),
	tags: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineTrends = mysqlTable("pipeline_trends", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 300 }).notNull(),
	nameEn: varchar({ length: 300 }),
	description: text(),
	category: varchar({ length: 100 }),
	maturityLevel: mysqlEnum(['emerging','growing','mature','declining']).default('emerging'),
	relevanceScore: int().default(50),
	impactScore: int().default(50),
	timeToMainstream: varchar({ length: 100 }),
	sources: json(),
	relatedInitiatives: json(),
	tags: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const pipelineVotes = mysqlTable("pipeline_votes", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	userId: int().notNull(),
	voteType: mysqlEnum(['upvote','downvote']).default('upvote'),
	comment: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const predictionAccuracy = mysqlTable("prediction_accuracy", {
	id: int().autoincrement().notNull(),
	analysisId: int().notNull(),
	predictedOutcome: mysqlEnum(['success','failure']).notNull(),
	predictedProbability: decimal({ precision: 5, scale: 4 }),
	actualOutcome: mysqlEnum(['success','failure','unknown']).default('unknown'),
	actualOutcomeDate: timestamp({ mode: 'string' }),
	correct: int(),
	errorMargin: decimal({ precision: 5, scale: 4 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const projectOrganizations = mysqlTable("project_organizations", {
	id: int().autoincrement().notNull(),
	projectId: int().notNull(),
	organizationId: int().notNull(),
	role: varchar({ length: 100 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const projects = mysqlTable("projects", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	category: varchar({ length: 100 }),
	subCategory: varchar({ length: 100 }),
	stage: mysqlEnum(['idea','prototype','mvp','growth','scale']).default('idea'),
	engine: mysqlEnum(['naqla1','naqla2','naqla3']).default('naqla1'),
	status: mysqlEnum(['draft','submitted','evaluating','approved','matched','contracted','completed','rejected','listed']).default('draft'),
	teamSize: int(),
	fundingNeeded: decimal({ precision: 15, scale: 2 }),
	fundingReceived: decimal({ precision: 15, scale: 2 }),
	targetMarket: text(),
	competitiveAdvantage: text(),
	businessModel: text(),
	documents: json(),
	images: json(),
	video: text(),
	website: text(),
	ipRegistrationId: int(),
	evaluationId: int(),
	contractId: int(),
	tags: json(),
	views: int().default(0),
	likes: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	pipelineIdeaId: int(),
});

export const ratTests = mysqlTable("rat_tests", {
	id: int().autoincrement().notNull(),
	hypothesisId: int().notNull(),
	userId: int().notNull(),
	testName: varchar({ length: 255 }).notNull(),
	testDescription: text(),
	plannedDate: timestamp({ mode: 'string' }),
	completedDate: timestamp({ mode: 'string' }),
	result: text(),
	status: mysqlEnum(['planned','in_progress','completed']).default('planned'),
	budget: decimal({ precision: 10, scale: 2 }),
	resources: json(),
	learnings: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const rolePermissions = mysqlTable("role_permissions", {
	id: int().autoincrement().notNull(),
	roleId: int().notNull(),
	permissionId: int().notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const roles = mysqlTable("roles", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 100 }).notNull(),
	displayName: varchar({ length: 200 }).notNull(),
	description: text(),
	isSystem: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("roles_name_unique").on(table.name),
]);

export const savedViews = mysqlTable("saved_views", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 255 }).notNull(),
	description: text(),
	viewType: varchar({ length: 50 }).notNull(),
	filters: json().notNull(),
	isPublic: int().default(0),
	sharedWith: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const sponsorRequests = mysqlTable("sponsor_requests", {
	id: int().autoincrement().notNull(),
	eventId: int("event_id").notNull().references(() => events.id, { onDelete: "cascade" } ),
	sponsorId: int("sponsor_id").notNull().references(() => users.id, { onDelete: "cascade" } ),
	packageType: varchar("package_type", { length: 100 }),
	packageValue: decimal("package_value", { precision: 12, scale: 2 }),
	benefits: json(),
	proposalDocument: text("proposal_document"),
	status: mysqlEnum(['pending','under_review','accepted','rejected','contract_signed']).default('pending'),
	reviewedBy: int("reviewed_by"),
	reviewDate: timestamp("review_date", { mode: 'string' }),
	reviewNotes: text("review_notes"),
	contractId: int("contract_id"),
	createdAt: timestamp("created_at", { mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const strategicAnalyses = mysqlTable("strategic_analyses", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	projectTitle: varchar({ length: 500 }).notNull(),
	projectDescription: text().notNull(),
	budget: decimal({ precision: 15, scale: 2 }),
	teamSize: int(),
	timelineMonths: int(),
	marketDemand: int(),
	technicalFeasibility: int(),
	userEngagement: int(),
	hypothesisValidationRate: decimal({ precision: 5, scale: 2 }),
	ratCompletionRate: decimal({ precision: 5, scale: 2 }),
	userCount: int(),
	revenueGrowth: decimal({ precision: 5, scale: 2 }),
	iciScore: decimal({ precision: 5, scale: 2 }),
	irlScore: decimal({ precision: 5, scale: 2 }),
	successProbability: decimal({ precision: 5, scale: 4 }),
	riskLevel: mysqlEnum(['CRITICAL','HIGH','MEDIUM','LOW']),
	investorAppeal: mysqlEnum(['VERY_LOW','LOW','MEDIUM','HIGH','VERY_HIGH']),
	ceoInsights: json(),
	roadmap: json(),
	investment: json(),
	criticalPath: json(),
	dashboard: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const strategicChallenges = mysqlTable("strategic_challenges", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleEn: varchar({ length: 500 }),
	description: text().notNull(),
	descriptionEn: text(),
	businessImpact: text(),
	stakeholders: json(),
	constraints: text(),
	successCriteria: text(),
	priority: mysqlEnum(['high','medium','low']).default('medium'),
	status: mysqlEnum(['active','in_progress','solved','archived']).default('active'),
	linkedInnovations: json(),
	tags: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const systemMetrics = mysqlTable("system_metrics", {
	id: int().autoincrement().notNull(),
	metricType: mysqlEnum(['api_call','error','performance','user_activity','database']).notNull(),
	metricName: varchar({ length: 200 }).notNull(),
	metricValue: decimal({ precision: 10, scale: 2 }),
	endpoint: varchar({ length: 500 }),
	method: varchar({ length: 10 }),
	statusCode: int(),
	responseTime: int(),
	errorMessage: text(),
	metadata: json(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const userFeedback = mysqlTable("user_feedback", {
	id: int().autoincrement().notNull(),
	analysisId: int(),
	userId: int(),
	projectId: varchar({ length: 500 }),
	feedbackType: mysqlEnum(['ceo_insight','roadmap','investment','general','whatif']).notNull(),
	itemId: int(),
	rating: varchar({ length: 50 }),
	comment: text(),
	userRole: varchar({ length: 50 }),
	sessionId: varchar({ length: 100 }),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const userRoles = mysqlTable("user_roles", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	roleId: int().notNull(),
	assignedBy: int(),
	assignedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	expiresAt: timestamp({ mode: 'string' }),
});

export const users = mysqlTable("users", {
	id: int().autoincrement().notNull(),
	openId: varchar({ length: 64 }).notNull(),
	name: text(),
	email: varchar({ length: 320 }),
	loginMethod: varchar({ length: 64 }),
	role: mysqlEnum(['user','admin','innovator','investor','company','government']).default('user').notNull(),
	entityType: mysqlEnum("entity_type", ['individual_innovator','individual_investor','local_company','foreign_company','government_entity','international_organization','research_institution','university','startup','ngo']).default('individual_innovator'),
	commercialRegistration: varchar("commercial_registration", { length: 100 }),
	licenseNumber: varchar("license_number", { length: 100 }),
	taxNumber: varchar("tax_number", { length: 100 }),
	entityCountry: varchar("entity_country", { length: 100 }),
	entityCity: varchar("entity_city", { length: 100 }),
	entityAddress: text("entity_address"),
	entityPhone: varchar("entity_phone", { length: 50 }),
	entityEmail: varchar("entity_email", { length: 320 }),
	authorizedPersonName: varchar("authorized_person_name", { length: 255 }),
	authorizedPersonPosition: varchar("authorized_person_position", { length: 255 }),
	entityDocuments: json("entity_documents"),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	lastSignedIn: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	phone: varchar({ length: 20 }),
	avatar: text(),
	organizationName: text(),
	organizationType: varchar({ length: 100 }),
	country: varchar({ length: 100 }),
	city: varchar({ length: 100 }),
	bio: text(),
	website: text(),
	linkedIn: text(),
	isVerified: int().default(0),
	verificationDate: timestamp({ mode: 'string' }),
	eliteMembership: mysqlEnum(['none','gold','platinum','diamond']).default('none'),
	membershipExpiry: timestamp({ mode: 'string' }),
	rememberMe: int().default(0),
	mfaEnabled: int().default(0),
	mfaSecret: varchar({ length: 255 }),
},
(table) => [
	index("users_openId_unique").on(table.openId),
]);

export const webhookLogs = mysqlTable("webhook_logs", {
	id: int().autoincrement().notNull(),
	webhookId: int().notNull(),
	event: varchar({ length: 100 }).notNull(),
	payload: json(),
	statusCode: int(),
	responseTime: int(),
	success: int().notNull(),
	errorMessage: text(),
	retryCount: int().default(0).notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const webhooks = mysqlTable("webhooks", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	name: varchar({ length: 255 }).notNull(),
	url: text().notNull(),
	secret: varchar({ length: 64 }),
	events: json(),
	isActive: int().default(1).notNull(),
	totalCalls: int().default(0).notNull(),
	successfulCalls: int().default(0).notNull(),
	failedCalls: int().default(0).notNull(),
	lastTriggeredAt: timestamp({ mode: 'string' }),
	lastError: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const whatifScenarios = mysqlTable("whatif_scenarios", {
	id: int().autoincrement().notNull(),
	analysisId: int().notNull(),
	userId: int(),
	scenarioName: varchar({ length: 200 }),
	modifications: json(),
	baselineIci: decimal({ precision: 5, scale: 2 }),
	modifiedIci: decimal({ precision: 5, scale: 2 }),
	baselineIrl: decimal({ precision: 5, scale: 2 }),
	modifiedIrl: decimal({ precision: 5, scale: 2 }),
	baselineSuccessProbability: decimal({ precision: 5, scale: 4 }),
	modifiedSuccessProbability: decimal({ precision: 5, scale: 4 }),
	impact: json(),
	recommendation: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const blockchainAssets = mysqlTable("blockchain_assets", {
	id: int().autoincrement().notNull(),
	ownerId: int().notNull(),
	type: mysqlEnum(['license', 'product', 'acquisition', 'partnership', 'service', 'investment', 'nda']).notNull(),
	title: varchar({ length: 500 }).notNull(),
	description: text().notNull(),
	category: varchar({ length: 100 }),
	price: decimal({ precision: 15, scale: 2 }).notNull(),
	currency: varchar({ length: 10 }).default('SAR'),
	status: mysqlEnum(['draft', 'active', 'sold', 'archived']).default('draft'),
	images: json(),
	documents: json(),
	specifications: json(),
	features: json(),
	views: int().default(0),
	likes: int().default(0),
	contactCount: int().default(0),
	blockchainHash: varchar({ length: 255 }),
	smartContractAddress: varchar({ length: 255 }),
	tokenId: varchar({ length: 100 }),
	verificationStatus: mysqlEnum(['pending', 'verified', 'rejected']).default('pending'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// Challenge Registration & Submissions System
export const challengeRegistrations = mysqlTable("challenge_registrations", {
	id: int().autoincrement().notNull(),
	challengeId: int().notNull(),
	userId: int().notNull(),
	teamName: varchar({ length: 200 }),
	teamMembers: json(), // Array of {name, email, role}
	status: mysqlEnum(['registered', 'submitted', 'under_review', 'accepted', 'rejected', 'winner']).default('registered'),
	registeredAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const challengeVotes = mysqlTable("challenge_votes", {
	id: int().autoincrement().notNull(),
	submissionId: int().notNull(),
	userId: int().notNull(),
	voteType: mysqlEnum(['public', 'judge']).default('public'),
	rating: int(), // 1-5 stars (optional)
	comment: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const challengeReviews = mysqlTable("challenge_reviews", {
	id: int().autoincrement().notNull(),
	submissionId: int().notNull(),
	reviewerId: int().notNull(),
	criteriaScores: json(), // {innovation: 8, feasibility: 7, impact: 9, ...}
	overallScore: decimal({ precision: 5, scale: 2 }).notNull(),
	strengths: text(),
	weaknesses: text(),
	recommendations: text(),
	decision: mysqlEnum(['shortlist', 'finalist', 'winner', 'reject']),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// ========================================
// الآلية المتكاملة الجديدة - Integrated Innovation System
// ========================================

// جدول AI Evaluations - تقييم الأفكار تلقائياً
export const aiEvaluations = mysqlTable("ai_evaluations", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	overallScore: decimal({ precision: 5, scale: 2 }).notNull(), // 0-100
	innovationScore: decimal({ precision: 5, scale: 2 }),
	feasibilityScore: decimal({ precision: 5, scale: 2 }),
	impactScore: decimal({ precision: 5, scale: 2 }),
	teamScore: decimal({ precision: 5, scale: 2 }),
	marketScore: decimal({ precision: 5, scale: 2 }),
	criteriaScores: json(), // جميع المعايير
	strengths: json(), // نقاط القوة
	weaknesses: json(), // نقاط الضعف
	opportunities: json(), // الفرص
	threats: json(), // التهديدات
	recommendations: json(), // التوصيات
	classificationPath: mysqlEnum(['innovation', 'commercial', 'guidance']), // المسار المقترح
	evaluatedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

// جدول Idea Classifications - تصنيف الأفكار إلى 3 مسارات
export const ideaClassifications = mysqlTable("idea_classifications", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	evaluationId: int().notNull(),
	classificationPath: mysqlEnum(['innovation', 'commercial', 'guidance']).notNull(),
	score: decimal({ precision: 5, scale: 2 }).notNull(),
	reason: text(), // سبب التصنيف
	nextSteps: json(), // الخطوات التالية المقترحة
	assignedPartnerId: int(), // الشريك الاستراتيجي المقترح
	status: mysqlEnum(['pending', 'accepted', 'rejected', 'completed']).default('pending'),
	classifiedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// جدول Strategic Partners - الشركاء الاستراتيجيون
export const strategicPartners = mysqlTable("strategic_partners", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 200 }).notNull(), // KAUST, SAIP, RDIA, MCIT, SDAIA, Monsha'at
	nameAr: varchar({ length: 200 }),
	type: mysqlEnum(['university', 'government', 'incubator', 'accelerator', 'investor', 'corporate']).notNull(),
	logo: varchar({ length: 500 }),
	website: varchar({ length: 500 }),
	description: text(),
	descriptionAr: text(),
	focusAreas: json(), // مجالات التركيز
	supportTypes: json(), // أنواع الدعم (funding, mentorship, infrastructure, etc.)
	eligibilityCriteria: json(), // معايير الأهلية
	contactEmail: varchar({ length: 200 }),
	contactPhone: varchar({ length: 50 }),
	status: mysqlEnum(['active', 'inactive', 'pending']).default('active'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// جدول Partner Projects - المشاريع المدعومة من الشركاء
export const partnerProjects = mysqlTable("partner_projects", {
	id: int().autoincrement().notNull(),
	partnerId: int().notNull(),
	ideaId: int().notNull(),
	projectName: varchar({ length: 300 }).notNull(),
	supportType: mysqlEnum(['funding', 'mentorship', 'infrastructure', 'training', 'networking', 'legal', 'marketing']).notNull(),
	fundingAmount: decimal({ precision: 15, scale: 2 }), // مبلغ التمويل (إن وُجد)
	startDate: timestamp({ mode: 'string' }),
	endDate: timestamp({ mode: 'string' }),
	status: mysqlEnum(['pending', 'active', 'completed', 'cancelled']).default('pending'),
	milestones: json(), // المعالم الرئيسية
	outcomes: json(), // النتائج المحققة
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// جدول Value Footprints - قياس الأثر
export const valueFootprints = mysqlTable("value_footprints", {
	id: int().autoincrement().notNull(),
	period: varchar({ length: 20 }).notNull(), // YYYY-MM (شهري) أو YYYY-Q1 (ربع سنوي) أو YYYY (سنوي)
	periodType: mysqlEnum(['monthly', 'quarterly', 'yearly']).notNull(),
	totalIdeas: int().default(0),
	totalStartups: int().default(0), // عدد الشركات الناشئة المؤسسة
	totalJobs: int().default(0), // عدد الوظائف المُنشأة
	totalRevenue: decimal({ precision: 18, scale: 2 }).default('0'), // الإيرادات المُحققة (ريال)
	gdpContribution: decimal({ precision: 10, scale: 4 }).default('0'), // المساهمة في GDP (%)
	globalInnovationRank: int(), // الترتيب في مؤشر الابتكار العالمي
	innovationPathCount: int().default(0), // عدد المشاريع في مسار Innovation
	commercialPathCount: int().default(0), // عدد المشاريع في مسار Commercial
	guidancePathCount: int().default(0), // عدد المشاريع في مسار Guidance
	vision2030Alignment: decimal({ precision: 5, scale: 2 }), // نسبة التوافق مع رؤية 2030 (%)
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// TypeScript types
export type AiEvaluation = typeof aiEvaluations.$inferSelect;
export type InsertAiEvaluation = typeof aiEvaluations.$inferInsert;

export type IdeaClassification = typeof ideaClassifications.$inferSelect;
export type InsertIdeaClassification = typeof ideaClassifications.$inferInsert;

export type StrategicPartner = typeof strategicPartners.$inferSelect;
export type InsertStrategicPartner = typeof strategicPartners.$inferInsert;

export type PartnerProject = typeof partnerProjects.$inferSelect;
export type InsertPartnerProject = typeof partnerProjects.$inferInsert;

export type ValueFootprint = typeof valueFootprints.$inferSelect;
export type InsertValueFootprint = typeof valueFootprints.$inferInsert;

// ============================================
// Agreements System - نظام الاتفاقات
// ============================================
export const agreements = mysqlTable("agreements", {
	id: int().autoincrement().notNull(),
	projectId: int().notNull(), // المشروع الطالب
	entityType: mysqlEnum(['challenge', 'accelerator', 'incubator', 'partner']).notNull(), // نوع الجهة
	entityId: int().notNull(), // ID الجهة (تحدي/مسرع/حاضنة/شريك)
	status: mysqlEnum(['pending', 'accepted', 'rejected', 'cancelled']).default('pending').notNull(),
	requestMessage: text(), // رسالة الطلب من المشروع
	responseMessage: text(), // رد الجهة (قبول/رفض)
	matchScore: decimal({ precision: 5, scale: 2 }), // نسبة المطابقة AI (0-100%)
	matchReasoning: text(), // أسباب المطابقة AI
	requesterId: int().notNull(), // من قدم الطلب (userId)
	responderId: int(), // من رد على الطلب (userId)
	respondedAt: timestamp({ mode: 'string' }), // تاريخ الرد
	promotedToNaqla3: int().default(0), // هل تم الانتقال إلى NAQLA 3 (0/1)
	promotedAt: timestamp({ mode: 'string' }), // تاريخ الانتقال
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const agreementMessages = mysqlTable("agreement_messages", {
	id: int().autoincrement().notNull(),
	agreementId: int().notNull(),
	senderId: int().notNull(), // userId
	message: text().notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export type Agreement = typeof agreements.$inferSelect;
export type InsertAgreement = typeof agreements.$inferInsert;

export type AgreementMessage = typeof agreementMessages.$inferSelect;
export type InsertAgreementMessage = typeof agreementMessages.$inferInsert;

// Additional TypeScript types for all tables
export type InsertUser = typeof users.$inferInsert;

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

export type IPRegistration = typeof ipRegistrations.$inferSelect;
export type InsertIPRegistration = typeof ipRegistrations.$inferInsert;

export type Evaluation = typeof evaluations.$inferSelect;
export type InsertEvaluation = typeof evaluations.$inferInsert;

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = typeof contracts.$inferInsert;

export type EscrowAccount = typeof escrowAccounts.$inferSelect;
export type InsertEscrowAccount = typeof escrowAccounts.$inferInsert;

export type InsertEscrowTransaction = typeof escrowTransactions.$inferInsert;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = typeof enrollments.$inferInsert;

export type EliteMembership = typeof eliteMemberships.$inferSelect;
export type InsertEliteMembership = typeof eliteMemberships.$inferInsert;

export type ApiKey = typeof apiKeys.$inferSelect;
export type InsertApiKey = typeof apiKeys.$inferInsert;

export type InsertApiUsage = typeof apiUsage.$inferInsert;

export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = typeof challenges.$inferInsert;

export type Ambassador = typeof ambassadors.$inferSelect;
export type InsertAmbassador = typeof ambassadors.$inferInsert;

export type InnovationHub = typeof innovationHubs.$inferSelect;
export type InsertInnovationHub = typeof innovationHubs.$inferInsert;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

export type InsertAnalytics = typeof analytics.$inferInsert;

export type PipelineInitiative = typeof pipelineInitiatives.$inferSelect;
export type InsertPipelineInitiative = typeof pipelineInitiatives.$inferInsert;

export type PipelineChallenge = typeof pipelineChallenges.$inferSelect;
export type InsertPipelineChallenge = typeof pipelineChallenges.$inferInsert;

export type PipelineIdea = typeof pipelineIdeas.$inferSelect;
export type InsertPipelineIdea = typeof pipelineIdeas.$inferInsert;

export type PipelineCluster = typeof pipelineClusters.$inferSelect;
export type InsertPipelineCluster = typeof pipelineClusters.$inferInsert;

export type PipelineHypothesis = typeof pipelineHypotheses.$inferSelect;
export type InsertPipelineHypothesis = typeof pipelineHypotheses.$inferInsert;

export type PipelineExperiment = typeof pipelineExperiments.$inferSelect;
export type InsertPipelineExperiment = typeof pipelineExperiments.$inferInsert;

export type InsertPipelineVote = typeof pipelineVotes.$inferInsert;

export type PipelineTrend = typeof pipelineTrends.$inferSelect;
export type InsertPipelineTrend = typeof pipelineTrends.$inferInsert;

export type InsertPipelineGamification = typeof pipelineGamification.$inferInsert;

export type StrategicAnalysis = typeof strategicAnalyses.$inferSelect;
export type InsertStrategicAnalysis = typeof strategicAnalyses.$inferInsert;

export type UserFeedback = typeof userFeedback.$inferSelect;
export type InsertUserFeedback = typeof userFeedback.$inferInsert;

export type WhatIfScenario = typeof whatifScenarios.$inferSelect;
export type InsertWhatIfScenario = typeof whatifScenarios.$inferInsert;

export type PredictionAccuracy = typeof predictionAccuracy.$inferSelect;
export type InsertPredictionAccuracy = typeof predictionAccuracy.$inferInsert;

export type ChallengeRegistration = typeof challengeRegistrations.$inferSelect;
export type InsertChallengeRegistration = typeof challengeRegistrations.$inferInsert;

export type ChallengeSubmission = typeof challengeSubmissions.$inferSelect;
export type InsertChallengeSubmission = typeof challengeSubmissions.$inferInsert;

export type ChallengeVote = typeof challengeVotes.$inferSelect;
export type InsertChallengeVote = typeof challengeVotes.$inferInsert;

export type ChallengeReview = typeof challengeReviews.$inferSelect;
export type InsertChallengeReview = typeof challengeReviews.$inferInsert;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

export type IdeaOutcome = typeof ideaOutcomes.$inferSelect;
export type InsertIdeaOutcome = typeof ideaOutcomes.$inferInsert;

export type SavedView = typeof savedViews.$inferSelect;
export type InsertSavedView = typeof savedViews.$inferInsert;

// ==================== Gemini Recommendations: Gamification System ====================
export const userPoints = mysqlTable("user_points", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	points: int().default(0).notNull(),
	level: int().default(1).notNull(),
	activityType: mysqlEnum(['idea_submitted','idea_approved','comment_added','vote_cast','challenge_created','challenge_completed','collaboration','badge_earned','referral']).notNull(),
	activityId: int(), // ID of the related activity
	pointsEarned: int().notNull(),
	description: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const userBadges = mysqlTable("user_badges", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	badgeId: int().notNull(),
	earnedAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	progress: int().default(0), // Progress towards next level (0-100%)
});

export const badges = mysqlTable("badges", {
	id: int().autoincrement().notNull(),
	name: varchar({ length: 200 }).notNull(),
	nameAr: varchar({ length: 200 }),
	description: text(),
	descriptionAr: text(),
	icon: varchar({ length: 500 }),
	category: mysqlEnum(['beginner','expert','innovator','collaborator','leader','special']).notNull(),
	requirement: json(), // Conditions to earn the badge
	pointsRequired: int().default(0),
	rarity: mysqlEnum(['common','uncommon','rare','epic','legendary']).default('common'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const userLevels = mysqlTable("user_levels", {
	id: int().autoincrement().notNull(),
	userId: int().notNull(),
	level: int().default(1).notNull(),
	totalPoints: int().default(0).notNull(),
	currentLevelPoints: int().default(0).notNull(),
	nextLevelPoints: int().default(100).notNull(),
	perks: json(), // Special perks for this level
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// ==================== Gemini Recommendations: Smart Evaluation Engine ====================
export const strategicGoals = mysqlTable("strategic_goals", {
	id: int().autoincrement().notNull(),
	title: varchar({ length: 500 }).notNull(),
	titleAr: varchar({ length: 500 }),
	description: text(),
	descriptionAr: text(),
	category: mysqlEnum(['vision2030','digital_transformation','sustainability','innovation','economic_growth','social_impact']).notNull(),
	keywords: json(), // Array of keywords
	weight: int().default(50), // Importance weight (1-100)
	status: mysqlEnum(['active','inactive','archived']).default('active'),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const ideaStrategicAlignment = mysqlTable("idea_strategic_alignment", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	goalId: int().notNull(),
	alignmentScore: decimal({ precision: 5, scale: 2 }).notNull(), // 0-100
	matchedKeywords: json(), // Array of matched keywords
	aiReasoning: text(), // AI explanation
	technicalFeasibility: decimal({ precision: 5, scale: 2 }), // 0-100
	expectedImpact: decimal({ precision: 5, scale: 2 }), // 0-100
	overallScore: decimal({ precision: 5, scale: 2 }), // Weighted average
	recommendations: json(), // Array of improvement suggestions
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

// ==================== Gemini Recommendations: Impact Dashboard (ROI²) ====================
export const ideaFinancialImpact = mysqlTable("idea_financial_impact", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	// Costs
	developmentCost: decimal({ precision: 15, scale: 2 }).default('0'),
	resourceCost: decimal({ precision: 15, scale: 2 }).default('0'),
	timeCost: decimal({ precision: 15, scale: 2 }).default('0'), // Hours × hourly rate
	totalCost: decimal({ precision: 15, scale: 2 }).default('0'),
	// Impact
	revenueGenerated: decimal({ precision: 15, scale: 2 }).default('0'),
	costSavings: decimal({ precision: 15, scale: 2 }).default('0'),
	totalImpact: decimal({ precision: 15, scale: 2 }).default('0'),
	// ROI²
	roi: decimal({ precision: 10, scale: 2 }), // (Impact - Cost) / Cost × 100%
	paybackPeriod: int(), // Months
	// Benchmarking
	industryAverage: decimal({ precision: 10, scale: 2 }),
	competitorBenchmark: decimal({ precision: 10, scale: 2 }),
	previousPerformance: decimal({ precision: 10, scale: 2 }),
	// Status
	status: mysqlEnum(['estimated','in_progress','completed','failed']).default('estimated'),
	notes: text(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
});

export const innovationMetrics = mysqlTable("innovation_metrics", {
	id: int().autoincrement().notNull(),
	period: mysqlEnum(['weekly','monthly','quarterly','yearly']).notNull(),
	periodStart: timestamp({ mode: 'string' }).notNull(),
	periodEnd: timestamp({ mode: 'string' }).notNull(),
	// Ideas
	totalIdeas: int().default(0),
	approvedIdeas: int().default(0),
	rejectedIdeas: int().default(0),
	successRate: decimal({ precision: 5, scale: 2 }), // %
	// Financial
	totalInvestment: decimal({ precision: 15, scale: 2 }).default('0'),
	totalReturn: decimal({ precision: 15, scale: 2 }).default('0'),
	averageROI: decimal({ precision: 10, scale: 2 }), // %
	// Flow
	naqla1ToNaqla2: int().default(0),
	naqla2ToNaqla3: int().default(0),
	naqla1ToNaqla3: int().default(0),
	// Engagement
	activeUsers: int().default(0),
	totalPoints: int().default(0),
	badgesEarned: int().default(0),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

// TypeScript types for new tables
export type UserPoint = typeof userPoints.$inferSelect;
export type InsertUserPoint = typeof userPoints.$inferInsert;

export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = typeof userBadges.$inferInsert;

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = typeof badges.$inferInsert;

export type UserLevel = typeof userLevels.$inferSelect;
export type InsertUserLevel = typeof userLevels.$inferInsert;

export type StrategicGoal = typeof strategicGoals.$inferSelect;
export type InsertStrategicGoal = typeof strategicGoals.$inferInsert;

export type IdeaStrategicAlignment = typeof ideaStrategicAlignment.$inferSelect;
export type InsertIdeaStrategicAlignment = typeof ideaStrategicAlignment.$inferInsert;

export type IdeaFinancialImpact = typeof ideaFinancialImpact.$inferSelect;
export type InsertIdeaFinancialImpact = typeof ideaFinancialImpact.$inferInsert;

export type InnovationMetric = typeof innovationMetrics.$inferSelect;
export type InsertInnovationMetric = typeof innovationMetrics.$inferInsert;

// User Choices & Journey Tracking
export const userChoices = mysqlTable("user_choices", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	userId: int().notNull(),
	choice: mysqlEnum(['naqla2','naqla3']).notNull(),
	notes: text(), // User notes explaining their choice
	projectId: int(), // If choice='naqla2'
	assetId: int(), // If choice='naqla3'
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

export const ideaJourneyEvents = mysqlTable("idea_journey_events", {
	id: int().autoincrement().notNull(),
	ideaId: int().notNull(),
	eventType: mysqlEnum(['submitted','analyzed','promoted_naqla2','promoted_naqla3','matched','funded','completed']).notNull(),
	eventData: json(), // Additional event-specific data
	timestamp: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
});

// TypeScript types
export type UserChoice = typeof userChoices.$inferSelect;
export type InsertUserChoice = typeof userChoices.$inferInsert;

export type IdeaJourneyEvent = typeof ideaJourneyEvents.$inferSelect;
export type InsertIdeaJourneyEvent = typeof ideaJourneyEvents.$inferInsert;
