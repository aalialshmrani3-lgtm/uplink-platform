#!/usr/bin/env python3
"""
UPLINK 5.0 - Enhanced Database Seeder for ideas_outcomes
Generates 500 realistic Arabic samples reflecting Saudi market
Focus: KAUST research, PIF challenges, Roshn projects, Southern Saudi regions
Distribution: 30% success, 70% failure (realistic startup ecosystem)
"""

import random
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from database_connector import DatabaseConnector
    DB_AVAILABLE = True
except ImportError:
    DB_AVAILABLE = False
    print("Warning: database_connector not available. Will generate JSON file only.")


# ============================================================================
# SAUDI MARKET DATA - Enhanced with Southern Regions & Realistic Failures
# ============================================================================

# Core sectors with focus on renewable energy, fintech, smart agriculture
SAUDI_SECTORS = {
    "renewable_energy": "الطاقة المتجددة والمستدامة",
    "fintech": "التقنية المالية والمدفوعات الرقمية",
    "smart_agriculture": "الزراعة الذكية والأمن الغذائي",
    "ai_tech": "الذكاء الاصطناعي والتقنيات المتقدمة",
    "digital_health": "الصحة الرقمية والتطبيب عن بُعد",
    "elearning": "التعليم الإلكتروني والتدريب المهني",
    "tourism": "السياحة والترفيه",
    "logistics": "اللوجستيات والنقل الذكي",
    "construction": "البناء والعقارات الذكية",
    "industry_4": "الصناعة 4.0 والأتمتة",
}

# Southern Saudi regions (Asir, Jazan, Najran, Baha)
SOUTHERN_REGIONS = [
    "منطقة عسير",
    "منطقة جازان",
    "منطقة نجران",
    "منطقة الباحة",
]

# Detailed failure reasons (for SHAP learning)
FAILURE_REASONS = {
    "market": [
        "سوق مشبع - لا توجد ميزة تنافسية واضحة",
        "حجم السوق المستهدف صغير جداً - لا يدعم النمو",
        "تقدير خاطئ للطلب في السوق - لا يوجد احتياج حقيقي",
        "منافسة شديدة من شركات عالمية كبرى",
        "عدم فهم احتياجات العملاء الفعلية",
        "تغيرات مفاجئة في اتجاهات السوق",
    ],
    "financial": [
        "ميزانية تسويق غير كافية - فشل في الوصول للعملاء",
        "نفاد رأس المال قبل تحقيق الإيرادات المستدامة",
        "تكاليف تشغيلية مرتفعة جداً - هامش ربح سلبي",
        "فشل في جذب المستثمرين للجولات التمويلية اللاحقة",
        "سوء إدارة التدفقات النقدية",
        "تقدير خاطئ لتكاليف اكتساب العملاء (CAC)",
    ],
    "technical": [
        "مشاكل تقنية متكررة - تجربة مستخدم سيئة",
        "عدم قابلية التوسع (scalability) - البنية التحتية ضعيفة",
        "تأخيرات كبيرة في التطوير - فقدان الميزة التنافسية",
        "اعتماد على تقنيات قديمة أو غير مناسبة",
        "ثغرات أمنية خطيرة - فقدان ثقة المستخدمين",
        "عدم توافق المنتج مع احتياجات السوق المحلية",
    ],
    "team": [
        "فريق غير متجانس - صراعات داخلية مستمرة",
        "نقص الخبرة في القطاع المستهدف",
        "استقالة أعضاء رئيسيين في الفريق",
        "عدم وجود قيادة واضحة - قرارات متضاربة",
        "فشل في توظيف المواهب المناسبة",
        "عدم التفرغ الكامل للمشروع من المؤسسين",
    ],
    "regulatory": [
        "تعقيدات تنظيمية - تأخير في الحصول على التراخيص",
        "تغييرات في الأنظمة واللوائح - زيادة تكاليف الامتثال",
        "عدم الالتزام بمعايير حماية البيانات",
        "صعوبة الحصول على الموافقات الحكومية المطلوبة",
    ],
    "execution": [
        "استراتيجية تسويق ضعيفة - عدم الوصول للجمهور المستهدف",
        "تركيز على المنتج دون الاهتمام بالمبيعات",
        "توسع سريع جداً - فقدان السيطرة على الجودة",
        "عدم التحقق من صحة الفرضيات (Hypothesis Validation) قبل الإطلاق",
        "إطلاق متأخر جداً - فقدان الفرصة السوقية",
        "عدم الاستماع لملاحظات العملاء - منتج لا يلبي الاحتياجات",
    ],
}


# ============================================================================
# KAUST-INSPIRED RESEARCH PROJECTS
# ============================================================================

KAUST_PROJECTS = [
    {
        "title": "نظام ذكاء اصطناعي لتحسين كفاءة الألواح الشمسية في المناطق الصحراوية",
        "description": "تطوير خوارزميات تعلم آلي لتحسين أداء الألواح الشمسية في الظروف الصحراوية القاسية مع تقليل تراكم الغبار وزيادة الكفاءة بنسبة 25%. يستخدم المشروع شبكات عصبية عميقة لتحليل بيانات الطقس والتنبؤ بأفضل زوايا التوجيه.",
        "sector": "renewable_energy",
        "budget_range": (800000, 2500000),
        "success_prob": 0.75,
        "region": "منطقة تبوك",
        "organization": "KAUST",
        "failure_reason": None,
    },
    {
        "title": "منصة blockchain لتتبع سلسلة التوريد الزراعية في جنوب المملكة",
        "description": "منصة لامركزية تستخدم تقنية البلوكشين لتتبع المنتجات الزراعية من المزرعة إلى المستهلك، مع ضمان الشفافية والجودة. تركز على المنتجات الزراعية في منطقة جازان وعسير مثل البن والعسل والفواكه الاستوائية.",
        "sector": "smart_agriculture",
        "budget_range": (600000, 1800000),
        "success_prob": 0.68,
        "region": "منطقة جازان",
        "organization": "KAUST",
        "failure_reason": None,
    },
    {
        "title": "نظام تحلية مياه بالطاقة الشمسية للمجتمعات الريفية",
        "description": "تطوير نظام تحلية مياه مبتكر يعمل بالطاقة الشمسية بتكلفة منخفضة، مستهدف للمجتمعات الريفية في جنوب المملكة. يستخدم تقنيات النانو لتحسين كفاءة التحلية وتقليل استهلاك الطاقة بنسبة 40%.",
        "sector": "renewable_energy",
        "budget_range": (1200000, 3500000),
        "success_prob": 0.72,
        "region": "منطقة نجران",
        "organization": "KAUST",
        "failure_reason": None,
    },
    {
        "title": "تطبيق ذكاء اصطناعي للتشخيص المبكر لأمراض النخيل",
        "description": "تطبيق يستخدم الرؤية الحاسوبية والتعلم العميق لتشخيص أمراض النخيل مبكراً من خلال تحليل صور الأوراق. يستهدف مزارع النخيل في الأحساء والقصيم مع دقة تشخيص تصل إلى 92%.",
        "sector": "smart_agriculture",
        "budget_range": (400000, 1200000),
        "success_prob": 0.70,
        "region": "منطقة الأحساء",
        "organization": "KAUST",
        "failure_reason": None,
    },
]


# ============================================================================
# PIF-BACKED CHALLENGES
# ============================================================================

PIF_PROJECTS = [
    {
        "title": "مصنع ذكي لإنتاج بطاريات الليثيوم للسيارات الكهربائية",
        "description": "إنشاء مصنع متطور لإنتاج بطاريات الليثيوم عالية الكفاءة للسيارات الكهربائية باستخدام تقنيات الصناعة 4.0 والأتمتة الكاملة. يهدف المشروع لتقليل الاعتماد على الواردات وتوطين صناعة السيارات الكهربائية في المملكة.",
        "sector": "industry_4",
        "budget_range": (5000000, 15000000),
        "success_prob": 0.78,
        "region": "المدينة الصناعية بالرياض",
        "organization": "PIF",
        "failure_reason": None,
    },
    {
        "title": "منصة تمويل جماعي (crowdfunding) للمشاريع الصغيرة والمتوسطة",
        "description": "منصة fintech تربط المستثمرين الأفراد بأصحاب المشاريع الصغيرة والمتوسطة، مع نظام تقييم ذكي للمخاطر يستخدم الذكاء الاصطناعي. تتوافق مع الأنظمة المالية السعودية وتدعم التمويل الإسلامي.",
        "sector": "fintech",
        "budget_range": (800000, 2500000),
        "success_prob": 0.65,
        "region": "الرياض",
        "organization": "PIF",
        "failure_reason": None,
    },
    {
        "title": "مزارع عمودية ذكية في المدن الكبرى",
        "description": "تطوير مزارع عمودية داخلية تستخدم الذكاء الاصطناعي وإنترنت الأشياء لتحسين الإنتاج الزراعي في المناطق الحضرية. تستهدف إنتاج الخضروات الورقية والأعشاب الطازجة بكفاءة عالية وبدون مبيدات.",
        "sector": "smart_agriculture",
        "budget_range": (1500000, 4000000),
        "success_prob": 0.70,
        "region": "جدة",
        "organization": "PIF",
        "failure_reason": None,
    },
    {
        "title": "نظام دفع رقمي متكامل للمتاجر الصغيرة",
        "description": "حل دفع رقمي شامل يستهدف المتاجر الصغيرة والبقالات، يدعم المدفوعات اللاcontactless، إدارة المخزون، وبرامج الولاء. يتكامل مع أنظمة الدفع الوطنية (مدى، Apple Pay، STC Pay).",
        "sector": "fintech",
        "budget_range": (600000, 1800000),
        "success_prob": 0.62,
        "region": "الدمام",
        "organization": "PIF",
        "failure_reason": None,
    },
]


# ============================================================================
# ROSHN-INSPIRED PROJECTS (Real Estate & Smart Cities)
# ============================================================================

ROSHN_PROJECTS = [
    {
        "title": "منصة إدارة ذكية للمجمعات السكنية",
        "description": "منصة متكاملة لإدارة المجمعات السكنية الحديثة تشمل إدارة الصيانة، الحجوزات، الدفع الإلكتروني، والتواصل مع السكان. تستهدف مشاريع روشن والمجمعات السكنية الكبرى في المملكة.",
        "sector": "construction",
        "budget_range": (500000, 1500000),
        "success_prob": 0.68,
        "region": "الرياض",
        "organization": "روشن",
        "failure_reason": None,
    },
    {
        "title": "نظام IoT لإدارة استهلاك الطاقة في المباني السكنية",
        "description": "نظام ذكي يستخدم إنترنت الأشياء والذكاء الاصطناعي لمراقبة وتحسين استهلاك الطاقة في المباني السكنية، مع توفير متوقع يصل إلى 30%. يتكامل مع أنظمة التكييف، الإضاءة، والأجهزة المنزلية الذكية.",
        "sector": "renewable_energy",
        "budget_range": (700000, 2000000),
        "success_prob": 0.72,
        "region": "جدة",
        "organization": "روشن",
        "failure_reason": None,
    },
    {
        "title": "تطبيق واقع معزز لتصميم وتخصيص الوحدات السكنية",
        "description": "تطبيق يستخدم الواقع المعزز (AR) لتمكين المشترين من تصميم وتخصيص وحداتهم السكنية قبل البناء، مع إمكانية تجربة الألوان، الأثاث، والتشطيبات افتراضياً.",
        "sector": "construction",
        "budget_range": (400000, 1200000),
        "success_prob": 0.65,
        "region": "الرياض",
        "organization": "روشن",
        "failure_reason": None,
    },
]


# ============================================================================
# FAILURE SCENARIOS (70% of dataset)
# ============================================================================

# Market-related failures
MARKET_FAILURES = [
    {
        "title": "تطبيق توصيل طعام تقليدي بدون ميزات فريدة",
        "description": "تطبيق توصيل طعام عام يستهدف السوق السعودي بدون أي ميزات تنافسية، في سوق يهيمن عليه Jahez وHungerStation وCareem. لا توجد استراتيجية واضحة للتمايز أو اكتساب حصة سوقية.",
        "sector": "logistics",
        "budget_range": (80000, 200000),
        "success_prob": 0.15,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "سوق مشبع - لا توجد ميزة تنافسية واضحة، منافسة شديدة من شركات عالمية كبرى",
    },
    {
        "title": "متجر إلكتروني عام بدون تخصص",
        "description": "متجر إلكتروني يبيع منتجات متنوعة بدون تخصص أو استراتيجية تسويق واضحة. يعتمد على الإعلانات المدفوعة فقط بميزانية محدودة، ولا يوجد تمايز عن Amazon وNoon.",
        "sector": "fintech",
        "budget_range": (50000, 150000),
        "success_prob": 0.12,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": "عدم فهم احتياجات العملاء الفعلية، ميزانية تسويق غير كافية - فشل في الوصول للعملاء",
    },
    {
        "title": "تطبيق شبكات اجتماعية محلي بدون قيمة مضافة",
        "description": "تطبيق شبكات اجتماعية يستهدف السوق السعودي فقط، يحاول منافسة Twitter وInstagram بدون أي ميزات فريدة أو مجتمع مستهدف واضح. فشل في اكتساب المستخدمين بسبب تأثير الشبكة (network effect).",
        "sector": "ai_tech",
        "budget_range": (150000, 400000),
        "success_prob": 0.10,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "منافسة شديدة من شركات عالمية كبرى، حجم السوق المستهدف صغير جداً - لا يدعم النمو",
    },
    {
        "title": "منصة حجز فنادق محلية بدون شراكات قوية",
        "description": "منصة حجز فنادق تستهدف السوق السعودي بدون شراكات قوية مع الفنادق الكبرى، وتواجه منافسة شرسة من Booking.com وAlmosafer. عدد الفنادق المتاحة محدود جداً.",
        "sector": "tourism",
        "budget_range": (200000, 500000),
        "success_prob": 0.18,
        "region": "مكة المكرمة",
        "organization": "شركة ناشئة",
        "failure_reason": "سوق مشبع - لا توجد ميزة تنافسية واضحة، فشل في جذب المستثمرين للجولات التمويلية اللاحقة",
    },
]

# Financial failures
FINANCIAL_FAILURES = [
    {
        "title": "منصة تعليم إلكتروني بميزانية تسويق ضعيفة",
        "description": "منصة تعليم إلكتروني تقدم دورات في البرمجة والتصميم، لكن مع ميزانية تسويق ضعيفة جداً (أقل من 10% من الميزانية الكلية). فشلت في الوصول للجمهور المستهدف رغم جودة المحتوى.",
        "sector": "elearning",
        "budget_range": (100000, 300000),
        "success_prob": 0.22,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "ميزانية تسويق غير كافية - فشل في الوصول للعملاء، تقدير خاطئ لتكاليف اكتساب العملاء (CAC)",
    },
    {
        "title": "تطبيق صحي رقمي بتكاليف تشغيلية مرتفعة",
        "description": "تطبيق يربط المرضى بالأطباء عن بُعد، لكن مع تكاليف تشغيلية مرتفعة جداً (رواتب أطباء، بنية تحتية، دعم فني). هامش الربح سلبي حتى مع نمو قاعدة المستخدمين.",
        "sector": "digital_health",
        "budget_range": (250000, 700000),
        "success_prob": 0.20,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": "تكاليف تشغيلية مرتفعة جداً - هامش ربح سلبي، نفاد رأس المال قبل تحقيق الإيرادات المستدامة",
    },
    {
        "title": "منصة تجارة إلكترونية بتقدير خاطئ للتكاليف",
        "description": "منصة تجارة إلكترونية متخصصة في الأزياء، لكن مع تقدير خاطئ جداً لتكاليف اكتساب العملاء (CAC) والشحن والمرتجعات. التكاليف الفعلية أعلى بـ 3x من التقديرات الأولية.",
        "sector": "fintech",
        "budget_range": (180000, 450000),
        "success_prob": 0.16,
        "region": "الدمام",
        "organization": "شركة ناشئة",
        "failure_reason": "تقدير خاطئ لتكاليف اكتساب العملاء (CAC), سوء إدارة التدفقات النقدية",
    },
]

# Technical failures
TECHNICAL_FAILURES = [
    {
        "title": "تطبيق دفع رقمي بمشاكل أمنية متكررة",
        "description": "تطبيق دفع رقمي يستهدف المتاجر الصغيرة، لكن مع ثغرات أمنية خطيرة تم اكتشافها بعد الإطلاق. فقدان ثقة المستخدمين والتجار بشكل كامل، وتحقيقات من البنك المركزي السعودي (SAMA).",
        "sector": "fintech",
        "budget_range": (300000, 800000),
        "success_prob": 0.08,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "ثغرات أمنية خطيرة - فقدان ثقة المستخدمين، تعقيدات تنظيمية - تأخير في الحصول على التراخيص",
    },
    {
        "title": "منصة حجز مواعيد طبية بمشاكل تقنية مستمرة",
        "description": "منصة حجز مواعيد طبية مع مشاكل تقنية متكررة (بطء، أعطال، فقدان بيانات). تجربة مستخدم سيئة جداً أدت إلى تقييمات سلبية وتراجع عدد المستخدمين بنسبة 60% خلال 3 أشهر.",
        "sector": "digital_health",
        "budget_range": (120000, 350000),
        "success_prob": 0.14,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": "مشاكل تقنية متكررة - تجربة مستخدم سيئة، عدم قابلية التوسع (scalability) - البنية التحتية ضعيفة",
    },
    {
        "title": "تطبيق زراعي ذكي بتقنيات قديمة",
        "description": "تطبيق لمراقبة المزارع عن بُعد يستخدم تقنيات قديمة وغير فعالة (sensors قديمة، اتصال بطيء). لا يتوافق مع احتياجات المزارعين الحديثة ولا يقدم قيمة حقيقية.",
        "sector": "smart_agriculture",
        "budget_range": (150000, 400000),
        "success_prob": 0.18,
        "region": "منطقة القصيم",
        "organization": "شركة ناشئة",
        "failure_reason": "اعتماد على تقنيات قديمة أو غير مناسبة، عدم توافق المنتج مع احتياجات السوق المحلية",
    },
]

# Team-related failures
TEAM_FAILURES = [
    {
        "title": "منصة لوجستية بفريق غير متجانس",
        "description": "منصة لوجستية لربط الشاحنات بالشركات، لكن مع فريق غير متجانس وصراعات داخلية مستمرة بين المؤسسين. قرارات متضاربة وعدم وجود رؤية موحدة أدت إلى فشل المشروع.",
        "sector": "logistics",
        "budget_range": (200000, 600000),
        "success_prob": 0.12,
        "region": "الدمام",
        "organization": "شركة ناشئة",
        "failure_reason": "فريق غير متجانس - صراعات داخلية مستمرة، عدم وجود قيادة واضحة - قرارات متضاربة",
    },
    {
        "title": "تطبيق سياحي بنقص خبرة في القطاع",
        "description": "تطبيق سياحي يستهدف السياحة الداخلية، لكن الفريق ليس لديه أي خبرة في قطاع السياحة أو الضيافة. قرارات خاطئة في اختيار الشركاء وتسعير الخدمات.",
        "sector": "tourism",
        "budget_range": (150000, 400000),
        "success_prob": 0.16,
        "region": "المدينة المنورة",
        "organization": "شركة ناشئة",
        "failure_reason": "نقص الخبرة في القطاع المستهدف، فشل في توظيف المواهب المناسبة",
    },
    {
        "title": "منصة تعليمية باستقالة المؤسس التقني",
        "description": "منصة تعليمية واعدة، لكن استقالة المؤسس التقني (CTO) بعد 8 أشهر من الإطلاق أدت إلى توقف التطوير وفقدان الزخم. فشل في إيجاد بديل مناسب.",
        "sector": "elearning",
        "budget_range": (180000, 500000),
        "success_prob": 0.14,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "استقالة أعضاء رئيسيين في الفريق، عدم التفرغ الكامل للمشروع من المؤسسين",
    },
]

# Execution failures
EXECUTION_FAILURES = [
    {
        "title": "تطبيق توصيل بقالة بتوسع سريع جداً",
        "description": "تطبيق توصيل بقالة توسع من مدينة واحدة إلى 5 مدن خلال 3 أشهر بدون بنية تحتية مناسبة. فقدان السيطرة على الجودة، تأخيرات مستمرة، وشكاوى كثيرة من العملاء.",
        "sector": "logistics",
        "budget_range": (250000, 700000),
        "success_prob": 0.18,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "توسع سريع جداً - فقدان السيطرة على الجودة، سوء إدارة التدفقات النقدية",
    },
    {
        "title": "منصة عقارية بإطلاق متأخر جداً",
        "description": "منصة عقارية لبيع وتأجير العقارات، لكن الإطلاق تأخر سنة كاملة عن الموعد المخطط. فقدان الفرصة السوقية ودخول منافسين أقوى خلال هذه الفترة.",
        "sector": "construction",
        "budget_range": (300000, 900000),
        "success_prob": 0.16,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": "إطلاق متأخر جداً - فقدان الفرصة السوقية، تأخيرات كبيرة في التطوير - فقدان الميزة التنافسية",
    },
    {
        "title": "تطبيق لياقة بدنية بدون التحقق من الفرضيات",
        "description": "تطبيق لياقة بدنية تم تطويره لمدة 10 أشهر بدون التحقق من صحة الفرضيات (Hypothesis Validation) أو اختبار السوق. بعد الإطلاق، اكتشف الفريق أن لا أحد يريد الدفع مقابل الخدمة.",
        "sector": "digital_health",
        "budget_range": (150000, 400000),
        "success_prob": 0.12,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "عدم التحقق من صحة الفرضيات (Hypothesis Validation) قبل الإطلاق، تقدير خاطئ للطلب في السوق - لا يوجد احتياج حقيقي",
    },
    {
        "title": "منصة تجارة إلكترونية بدون الاستماع للعملاء",
        "description": "منصة تجارة إلكترونية متخصصة في الإلكترونيات، لكن الفريق لم يستمع لملاحظات العملاء المبكرة حول صعوبة الاستخدام ومشاكل الدفع. استمروا في نفس الاتجاه حتى فقدوا معظم العملاء.",
        "sector": "fintech",
        "budget_range": (200000, 550000),
        "success_prob": 0.14,
        "region": "الدمام",
        "organization": "شركة ناشئة",
        "failure_reason": "عدم الاستماع لملاحظات العملاء - منتج لا يلبي الاحتياجات، استراتيجية تسويق ضعيفة - عدم الوصول للجمهور المستهدف",
    },
]

# Regulatory failures
REGULATORY_FAILURES = [
    {
        "title": "منصة تمويل P2P بتعقيدات تنظيمية",
        "description": "منصة تمويل peer-to-peer واجهت تعقيدات تنظيمية كبيرة من البنك المركزي السعودي (SAMA) وهيئة السوق المالية. تأخير 18 شهر في الحصول على التراخيص المطلوبة، مما أدى إلى نفاد رأس المال.",
        "sector": "fintech",
        "budget_range": (400000, 1200000),
        "success_prob": 0.10,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": "تعقيدات تنظيمية - تأخير في الحصول على التراخيص، نفاد رأس المال قبل تحقيق الإيرادات المستدامة",
    },
    {
        "title": "تطبيق صحي بعدم الالتزام بحماية البيانات",
        "description": "تطبيق صحي لم يلتزم بمعايير حماية البيانات الصحية المطلوبة من وزارة الصحة. تم إيقاف الخدمة بعد 4 أشهر من الإطلاق وفرض غرامات كبيرة على الشركة.",
        "sector": "digital_health",
        "budget_range": (200000, 600000),
        "success_prob": 0.08,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": "عدم الالتزام بمعايير حماية البيانات، صعوبة الحصول على الموافقات الحكومية المطلوبة",
    },
]


# ============================================================================
# MODERATE SUCCESS SCENARIOS (remaining ~10-15%)
# ============================================================================

MODERATE_PROJECTS = [
    {
        "title": "نظام إدارة مخزون للمطاعم الصغيرة",
        "description": "نظام سحابي بسيط لإدارة المخزون والطلبات للمطاعم الصغيرة والمتوسطة. يقدم قيمة واضحة لكن في سوق متخصص محدود. نمو بطيء لكن مستقر.",
        "sector": "ai_tech",
        "budget_range": (100000, 300000),
        "success_prob": 0.50,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": None,
    },
    {
        "title": "منصة تدريب مهني عن بُعد في مجالات محددة",
        "description": "منصة تقدم دورات تدريبية مهنية معتمدة في مجالات محددة (محاسبة، موارد بشرية). جودة جيدة لكن منافسة متوسطة وتسويق محدود.",
        "sector": "elearning",
        "budget_range": (150000, 450000),
        "success_prob": 0.48,
        "region": "جدة",
        "organization": "شركة ناشئة",
        "failure_reason": None,
    },
    {
        "title": "تطبيق حجز صالونات تجميل",
        "description": "تطبيق يربط العملاء بصالونات التجميل لحجز المواعيد. خدمة مفيدة لكن في سوق متخصص، مع منافسة من تطبيقات عامة أكبر.",
        "sector": "digital_health",
        "budget_range": (80000, 250000),
        "success_prob": 0.52,
        "region": "الرياض",
        "organization": "شركة ناشئة",
        "failure_reason": None,
    },
    {
        "title": "منصة توظيف متخصصة في القطاع الصحي",
        "description": "منصة توظيف تربط الأطباء والممرضين بالمستشفيات والعيادات. تخصص واضح لكن حجم سوق محدود ومنافسة من منصات التوظيف العامة.",
        "sector": "ai_tech",
        "budget_range": (120000, 350000),
        "success_prob": 0.46,
        "region": "الدمام",
        "organization": "شركة ناشئة",
        "failure_reason": None,
    },
]


# ============================================================================
# FEATURE GENERATION FUNCTIONS
# ============================================================================

def generate_realistic_features(
    budget: float,
    success_prob: float,
    sector: str
) -> Dict[str, Any]:
    """Generate realistic feature values based on budget and success probability"""
    
    # Team size correlates with budget and success
    if budget < 100000:
        team_size = random.randint(2, 4)
    elif budget < 500000:
        team_size = random.randint(3, 8)
    elif budget < 2000000:
        team_size = random.randint(6, 15)
    else:
        team_size = random.randint(12, 40)
    
    # Timeline correlates with budget
    if budget < 100000:
        timeline_months = random.randint(3, 6)
    elif budget < 500000:
        timeline_months = random.randint(6, 12)
    elif budget < 2000000:
        timeline_months = random.randint(12, 24)
    else:
        timeline_months = random.randint(18, 36)
    
    # Success-correlated features (with realistic noise)
    base_quality = success_prob * 100
    noise = random.uniform(-12, 12)
    
    market_demand = max(10, min(100, int(base_quality + noise + random.uniform(-8, 8))))
    technical_feasibility = max(10, min(100, int(base_quality + noise + random.uniform(-6, 6))))
    competitive_advantage = max(10, min(100, int(base_quality + noise + random.uniform(-15, 15))))
    user_engagement = max(10, min(100, int(base_quality + noise + random.uniform(-10, 10))))
    
    # Hypothesis validation and RAT completion (higher for successful projects)
    hypothesis_validation_rate = max(0.0, min(1.0, success_prob + random.uniform(-0.20, 0.20)))
    rat_completion_rate = max(0.0, min(1.0, success_prob + random.uniform(-0.25, 0.25)))
    
    # Tags count (more tags for well-researched projects)
    tags_count = random.randint(5, 15) if success_prob > 0.5 else random.randint(1, 7)
    
    return {
        "budget": budget,
        "team_size": team_size,
        "timeline_months": timeline_months,
        "market_demand": market_demand,
        "technical_feasibility": technical_feasibility,
        "competitive_advantage": competitive_advantage,
        "user_engagement": user_engagement,
        "tags_count": tags_count,
        "hypothesis_validation_rate": round(hypothesis_validation_rate, 2),
        "rat_completion_rate": round(rat_completion_rate, 2),
    }


def generate_success_metrics(success: bool, sector: str) -> Dict[str, Any]:
    """Generate realistic success metrics"""
    if success:
        return {
            "revenue_growth": f"{random.randint(60, 350)}%",
            "user_count": random.randint(2000, 150000),
            "market_share": f"{random.randint(8, 45)}%",
            "roi": f"{random.randint(150, 600)}%",
            "customer_satisfaction": f"{random.randint(80, 98)}%",
        }
    else:
        return {
            "revenue_growth": f"{random.randint(-80, 15)}%",
            "user_count": random.randint(5, 400),
            "market_share": f"{random.randint(0, 4)}%",
            "roi": f"{random.randint(-95, 40)}%",
            "customer_satisfaction": f"{random.randint(25, 55)}%",
        }


def generate_outcome_date() -> datetime:
    """Generate random outcome date within last 2 years"""
    days_ago = random.randint(30, 730)  # 1 month to 2 years
    return datetime.now() - timedelta(days=days_ago)


# ============================================================================
# SEEDING FUNCTIONS
# ============================================================================

def generate_samples(count: int = 500) -> List[Dict[str, Any]]:
    """
    Generate 500 realistic Saudi market samples
    Distribution: 30% success, 70% failure (realistic startup ecosystem)
    """
    samples = []
    
    # Calculate distribution (30% success, 70% failure)
    success_count = int(count * 0.30)  # 150 successful projects
    failure_count = count - success_count  # 350 failed projects
    
    # Success distribution
    kaust_count = int(success_count * 0.25)  # 37-38 KAUST projects
    pif_count = int(success_count * 0.25)  # 37-38 PIF projects
    roshn_count = int(success_count * 0.20)  # 30 Roshn projects
    moderate_count = success_count - kaust_count - pif_count - roshn_count  # ~45 moderate
    
    # Failure distribution
    market_fail = int(failure_count * 0.30)  # 105 market failures
    financial_fail = int(failure_count * 0.25)  # 87 financial failures
    technical_fail = int(failure_count * 0.20)  # 70 technical failures
    team_fail = int(failure_count * 0.15)  # 52 team failures
    execution_fail = int(failure_count * 0.07)  # 24 execution failures
    regulatory_fail = failure_count - market_fail - financial_fail - technical_fail - team_fail - execution_fail  # ~12
    
    print(f"\n{'='*60}")
    print(f"UPLINK 5.0 - Enhanced Database Seeder")
    print(f"{'='*60}")
    print(f"\nGenerating {count} realistic Saudi market samples:")
    print(f"\n✅ SUCCESS SCENARIOS ({success_count} samples - 30%):")
    print(f"  - KAUST research projects: {kaust_count}")
    print(f"  - PIF-backed challenges: {pif_count}")
    print(f"  - Roshn smart city projects: {roshn_count}")
    print(f"  - Moderate success projects: {moderate_count}")
    print(f"\n❌ FAILURE SCENARIOS ({failure_count} samples - 70%):")
    print(f"  - Market-related failures: {market_fail}")
    print(f"  - Financial failures: {financial_fail}")
    print(f"  - Technical failures: {technical_fail}")
    print(f"  - Team-related failures: {team_fail}")
    print(f"  - Execution failures: {execution_fail}")
    print(f"  - Regulatory failures: {regulatory_fail}")
    print(f"\n{'='*60}\n")
    
    # Generate SUCCESS samples
    print("Generating success samples...")
    
    # KAUST projects
    for i in range(kaust_count):
        project = random.choice(KAUST_PROJECTS)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"KAUST_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(SOUTHERN_REGIONS)),
            "organization": project["organization"],
            "outcome": "success",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": None,
            **features,
            **generate_success_metrics(True, project["sector"]),
        }
        samples.append(sample)
    
    # PIF projects
    for i in range(pif_count):
        project = random.choice(PIF_PROJECTS)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"PIF_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", "الرياض"),
            "organization": project["organization"],
            "outcome": "success",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": None,
            **features,
            **generate_success_metrics(True, project["sector"]),
        }
        samples.append(sample)
    
    # Roshn projects
    for i in range(roshn_count):
        project = random.choice(ROSHN_PROJECTS)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"ROSHN_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", "الرياض"),
            "organization": project["organization"],
            "outcome": "success",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": None,
            **features,
            **generate_success_metrics(True, project["sector"]),
        }
        samples.append(sample)
    
    # Moderate success projects
    for i in range(moderate_count):
        project = random.choice(MODERATE_PROJECTS)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        # 50/50 chance of success or failure for moderate projects
        outcome = "success" if random.random() < project["success_prob"] else "failure"
        
        # Generate failure reason for moderate projects that fail
        failure_reason = None
        if outcome == "failure":
            # Choose random failure reason from market or financial categories
            failure_category = random.choice(["market", "financial"])
            failure_reason = random.choice(FAILURE_REASONS[failure_category])
        
        sample = {
            "idea_id": f"MOD_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": outcome,
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": failure_reason,
            **features,
            **generate_success_metrics(outcome == "success", project["sector"]),
        }
        samples.append(sample)
    
    # Generate FAILURE samples
    print("Generating failure samples...")
    
    # Market failures
    for i in range(market_fail):
        project = random.choice(MARKET_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_MKT_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Financial failures
    for i in range(financial_fail):
        project = random.choice(FINANCIAL_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_FIN_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Technical failures
    for i in range(technical_fail):
        project = random.choice(TECHNICAL_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_TECH_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Team failures
    for i in range(team_fail):
        project = random.choice(TEAM_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_TEAM_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Execution failures
    for i in range(execution_fail):
        project = random.choice(EXECUTION_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_EXEC_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة", "الدمام"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Regulatory failures
    for i in range(regulatory_fail):
        project = random.choice(REGULATORY_FAILURES)
        budget = random.randint(project["budget_range"][0], project["budget_range"][1])
        features = generate_realistic_features(budget, project["success_prob"], project["sector"])
        
        sample = {
            "idea_id": f"FAIL_REG_{i+1:03d}",
            "title": project["title"],
            "description": project["description"],
            "sector": SAUDI_SECTORS[project["sector"]],
            "region": project.get("region", random.choice(["الرياض", "جدة"])),
            "organization": project["organization"],
            "outcome": "failure",
            "outcome_date": generate_outcome_date().isoformat(),
            "failure_reason": project["failure_reason"],
            **features,
            **generate_success_metrics(False, project["sector"]),
        }
        samples.append(sample)
    
    # Shuffle samples to mix success and failure
    random.shuffle(samples)
    
    print(f"\n✅ Generated {len(samples)} samples successfully!")
    return samples


def save_to_json(samples: List[Dict[str, Any]], filename: str = "ideas_outcomes_seed_data.json"):
    """Save samples to JSON file"""
    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(samples, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Saved to JSON: {filepath}")
    return filepath


def seed_database(samples: List[Dict[str, Any]]):
    """Seed database with samples"""
    if not DB_AVAILABLE:
        print("\n⚠️  Database connector not available. Skipping database seeding.")
        return
    
    try:
        db = DatabaseConnector()
        print("\n🔄 Seeding database...")
        
        success_count = 0
        for sample in samples:
            try:
                db.insert_idea_outcome(sample)
                success_count += 1
                if success_count % 50 == 0:
                    print(f"  Inserted {success_count}/{len(samples)} samples...")
            except Exception as e:
                print(f"  ⚠️  Failed to insert {sample['idea_id']}: {e}")
        
        print(f"\n✅ Successfully seeded {success_count}/{len(samples)} samples to database!")
        
    except Exception as e:
        print(f"\n❌ Database seeding failed: {e}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Main execution function"""
    print("\n" + "="*60)
    print("UPLINK 5.0 - Enhanced Database Seeder")
    print("Realistic Saudi Market Data Generator")
    print("="*60 + "\n")
    
    # Generate samples
    samples = generate_samples(count=500)
    
    # Save to JSON
    json_path = save_to_json(samples)
    
    # Seed database (if available)
    seed_database(samples)
    
    # Print summary statistics
    success_samples = [s for s in samples if s["outcome"] == "success"]
    failure_samples = [s for s in samples if s["outcome"] == "failure"]
    
    print(f"\n{'='*60}")
    print("SUMMARY STATISTICS")
    print(f"{'='*60}")
    print(f"\nTotal samples: {len(samples)}")
    print(f"Success: {len(success_samples)} ({len(success_samples)/len(samples)*100:.1f}%)")
    print(f"Failure: {len(failure_samples)} ({len(failure_samples)/len(samples)*100:.1f}%)")
    
    # Sector distribution
    print(f"\nSector Distribution:")
    sectors = {}
    for sample in samples:
        sector = sample["sector"]
        sectors[sector] = sectors.get(sector, 0) + 1
    for sector, count in sorted(sectors.items(), key=lambda x: x[1], reverse=True):
        print(f"  {sector}: {count}")
    
    # Organization distribution
    print(f"\nOrganization Distribution:")
    orgs = {}
    for sample in samples:
        org = sample["organization"]
        orgs[org] = orgs.get(org, 0) + 1
    for org, count in sorted(orgs.items(), key=lambda x: x[1], reverse=True):
        print(f"  {org}: {count}")
    
    # Failure reasons distribution
    print(f"\nTop 10 Failure Reasons:")
    failure_reasons = {}
    for sample in failure_samples:
        if sample["failure_reason"]:
            reason = sample["failure_reason"]
            failure_reasons[reason] = failure_reasons.get(reason, 0) + 1
    for reason, count in sorted(failure_reasons.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {reason[:60]}...: {count}")
    
    print(f"\n{'='*60}")
    print("✅ Database seeding completed successfully!")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
