export const en = {
  // Common
  common: {
    home: 'Home',
    dashboard: 'Dashboard',
    login: 'Login',
    logout: 'Logout',
    register: 'Register',
    profile: 'Profile',
    settings: 'Settings',
    search: 'Search',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    view: 'View',
    back: 'Back',
    next: 'Next',
    previous: 'Previous',
    submit: 'Submit',
    loading: 'Loading...',
    noResults: 'No results found',
    all: 'All',
    active: 'Active',
    inactive: 'Inactive',
    pending: 'Pending',
    approved: 'Approved',
    rejected: 'Rejected',
    comingSoon: 'Coming Soon',
  },

  // Navigation
  nav: {
    engines: 'Engines',
    features: 'Features',
    partners: 'Partners',
    academy: 'Academy',
    marketplace: 'Marketplace',
    challenges: 'Challenges',
    elite: 'Elite',
    developers: 'Developers',
    analytics: 'Analytics',
    messages: 'Messages',
    notifications: 'Notifications',
    calendar: 'Calendar',
    whiteboard: 'Whiteboard',
    contracts: 'Contracts',
    admin: 'Admin Panel',
    pipeline: 'Innovation Pipeline',
    aiInsights: 'AI Insights',
    whyNaqla: 'Why NAQLA',
    testimonials: 'Testimonials',
    integrations: 'Integrations',
    roiCalculator: 'ROI Calculator',
    help: 'Help',
    caseStudies: 'Case Studies',
  },

  // Home Page
  home: {
    badge: 'Global Innovation Ecosystem',
    title: 'Transform Your Ideas Into',
    titleHighlight: 'Global Innovations',
    description: 'NAQLA 5.0 connects innovators worldwide with investors, companies, and institutions through three integrated engines: IP Generation, Challenges & Matching, and Open Marketplace',
    cta: 'Register Your Innovation Now',
    exploreEngines: 'Explore Engines',
    stats: {
      innovations: 'Registered Innovations',
      investors: 'Active Investors',
      partnerships: 'Strategic Partnerships',
      funding: 'USD Investments',
    },
  },

  // Engines
  engines: {
    title: 'The Three Engines',
    subtitle: 'Integrated Innovation Ecosystem',
    description: 'From idea to global market, we provide everything you need to turn your innovation into success',
    naqla1: {
      name: 'NAQLA1',
      title: 'IP Generation',
      description: 'Register and protect intellectual property via SAIP & WIPO with blockchain documentation',
      features: ['Patents', 'Trademarks', 'Blockchain Documentation'],
    },
    naqla2: {
      name: 'NAQLA2',
      title: 'Challenges & Matching',
      description: 'Advanced AI evaluation and smart matching with suitable investors and companies',
      features: ['AI Evaluation', 'Challenges & Competitions', 'Smart Matching'],
    },
    naqla3: {
      name: 'NAQLA3',
      title: 'Market & Exchange',
      description: 'Open marketplace for innovations with smart contracts and Escrow system',
      features: ['Smart Contracts', 'Escrow System', 'Open Market'],
    },
    explore: 'Explore More',
  },

  // Features
  features: {
    title: 'Why NAQLA 5.0?',
    subtitle: 'Unique features that make our platform the first choice for innovators worldwide',
    aiEvaluation: {
      title: 'Advanced AI Evaluation',
      description: 'Triple-axis evaluation system analyzing innovation, commercial viability, and required guidance',
    },
    ipProtection: {
      title: 'IP Protection',
      description: 'Integration with WIPO & USPTO for patent and trademark registration',
    },
    smartContracts: {
      title: 'Smart Contracts',
      description: 'Smart contract system with Escrow to protect all parties\' rights',
    },
    analytics: {
      title: 'Advanced Analytics',
      description: 'Comprehensive dashboard with KPIs and detailed reports',
    },
    secureMessaging: {
      title: 'Secure Communication',
      description: 'Encrypted messaging system for direct communication between innovators and investors',
    },
    ideaBoard: {
      title: 'Interactive Idea Board',
      description: 'Visual collaboration tool for developing ideas with the team in real-time',
    },
  },

  // Partners
  partners: {
    title: 'Success Partners',
    subtitle: 'We are proud of our partnerships with leading Saudi institutions and companies',
  },

  // CTA
  cta: {
    title: 'Start Your Innovation Journey Today',
    subtitle: 'Join the global innovators community and get full support to turn your idea into reality',
    learnInAcademy: 'Learn in Academy',
  },

  // Footer
  footer: {
    description: 'Global Innovation Platform',
    engines: 'Engines',
    resources: 'Resources',
    tools: 'Tools',
    ip: 'Intellectual Property',
    privacy: 'Privacy Policy',
    terms: 'Terms & Conditions',
    copyright: 'All Rights Reserved',
    followUs: 'Follow Us',
    newsletter: 'Subscribe to Newsletter',
    newsletterPlaceholder: 'Enter your email',
    subscribe: 'Subscribe',
    company: 'Company',
    about: 'About Us',
    careers: 'Careers',
    press: 'Press',
    blog: 'Blog',
    support: 'Support',
    documentation: 'Documentation',
    community: 'Community',
    contact: 'Contact Us',
  },

  // Dashboard
  dashboard: {
    welcome: 'Welcome',
    overview: 'Overview',
    myProjects: 'My Projects',
    myIP: 'My IP',
    myContracts: 'My Contracts',
    quickActions: 'Quick Actions',
    newProject: 'New Project',
    registerIP: 'Register IP',
    viewAnalytics: 'View Analytics',
    recentActivity: 'Recent Activity',
  },

  // Projects
  projects: {
    title: 'Projects',
    newProject: 'New Project',
    projectName: 'Project Name',
    description: 'Description',
    sector: 'Sector',
    stage: 'Stage',
    funding: 'Required Funding',
    status: 'Status',
    evaluation: 'Evaluation',
    stages: {
      idea: 'Idea',
      prototype: 'Prototype',
      mvp: 'MVP',
      growth: 'Growth',
      expansion: 'Expansion',
    },
    sectors: {
      healthcare: 'Healthcare',
      fintech: 'FinTech',
      education: 'Education',
      energy: 'Energy',
      logistics: 'Logistics',
      other: 'Other',
    },
  },

  // Recommendations
  recommendations: {
    title: 'Smart Recommendations',
    subtitle: 'Suitable investors for your project',
    matchScore: 'Match Score',
    viewProfile: 'View Profile',
    sendMessage: 'Send Message',
    noRecommendations: 'No recommendations available',
    basedOn: 'Based on',
    sector: 'Sector',
    stage: 'Stage',
    fundingRange: 'Funding Range',
  },

  // Admin
  admin: {
    title: 'Admin Panel',
    users: 'Users',
    projects: 'Projects',
    approvals: 'Approvals',
    statistics: 'Statistics',
    userManagement: 'User Management',
    projectManagement: 'Project Management',
    approvalQueue: 'Approval Queue',
    systemStats: 'System Statistics',
    actions: {
      activate: 'Activate',
      deactivate: 'Deactivate',
      approve: 'Approve',
      reject: 'Reject',
      review: 'Review',
    },
  },

  // Profile
  profile: {
    title: 'Profile',
    personalInfo: 'Personal Information',
    fullName: 'Full Name',
    email: 'Email',
    phone: 'Phone Number',
    bio: 'Bio',
    location: 'Location',
    website: 'Website',
    socialMedia: 'Social Media',
    expertise: 'Expertise',
    interests: 'Interests',
    updateProfile: 'Update Profile',
    changePassword: 'Change Password',
    currentPassword: 'Current Password',
    newPassword: 'New Password',
    confirmPassword: 'Confirm Password',
  },

  // Analytics
  analytics: {
    title: 'Analytics',
    overview: 'Overview',
    performance: 'Performance',
    trends: 'Trends',
    insights: 'Insights',
    metrics: 'Metrics',
    reports: 'Reports',
    export: 'Export',
    filter: 'Filter',
    dateRange: 'Date Range',
    customRange: 'Custom Range',
    last7Days: 'Last 7 Days',
    last30Days: 'Last 30 Days',
    last90Days: 'Last 90 Days',
    thisYear: 'This Year',
  },

  // Messages
  messages: {
    title: 'Messages',
    inbox: 'Inbox',
    sent: 'Sent',
    drafts: 'Drafts',
    archived: 'Archived',
    compose: 'Compose Message',
    to: 'To',
    subject: 'Subject',
    message: 'Message',
    send: 'Send',
    reply: 'Reply',
    forward: 'Forward',
    archive: 'Archive',
    markAsRead: 'Mark as Read',
    markAsUnread: 'Mark as Unread',
    noMessages: 'No messages',
  },

  // Calendar
  calendar: {
    title: 'Calendar',
    today: 'Today',
    month: 'Month',
    week: 'Week',
    day: 'Day',
    agenda: 'Agenda',
    addEvent: 'Add Event',
    eventTitle: 'Event Title',
    startDate: 'Start Date',
    endDate: 'End Date',
    location: 'Location',
    description: 'Description',
    attendees: 'Attendees',
    reminder: 'Reminder',
    noEvents: 'No events',
  },

  // Whiteboard
  whiteboard: {
    title: 'Whiteboard',
    newBoard: 'New Board',
    share: 'Share',
    export: 'Export',
    tools: 'Tools',
    pen: 'Pen',
    eraser: 'Eraser',
    shapes: 'Shapes',
    text: 'Text',
    sticky: 'Sticky Note',
    image: 'Image',
    undo: 'Undo',
    redo: 'Redo',
    clear: 'Clear',
    collaborators: 'Collaborators',
  },

  // Academy
  academy: {
    title: 'NAQLA Academy',
    courses: 'Courses',
    workshops: 'Workshops',
    webinars: 'Webinars',
    resources: 'Resources',
    myCourses: 'My Courses',
    browse: 'Browse',
    enroll: 'Enroll',
    continue: 'Continue',
    completed: 'Completed',
    inProgress: 'In Progress',
    notStarted: 'Not Started',
    certificate: 'Certificate',
  },

  // Pipeline
  pipeline: {
    title: 'Innovation Pipeline',
    stages: 'Stages',
    ideation: 'Ideation',
    validation: 'Validation',
    development: 'Development',
    testing: 'Testing',
    launch: 'Launch',
    scale: 'Scale',
    moveToStage: 'Move to Stage',
    addNote: 'Add Note',
    viewDetails: 'View Details',
  },

  // AI Insights
  aiInsights: {
    title: 'AI Insights',
    predictions: 'Predictions',
    recommendations: 'Recommendations',
    trends: 'Trends',
    opportunities: 'Opportunities',
    risks: 'Risks',
    score: 'Score',
    confidence: 'Confidence',
    learnMore: 'Learn More',
  },

  // Language
  language: {
    select: 'Select Language',
    ar: 'العربية',
    en: 'English',
    fr: 'Français',
    es: 'Español',
    zh: '中文',
  },
};

export default en;
